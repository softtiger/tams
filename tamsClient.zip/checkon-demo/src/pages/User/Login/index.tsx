import { Footer } from '@/components';
import { login } from '@/services/ant-design-pro/api';
import { getFakeCaptcha } from '@/services/ant-design-pro/login';
import { getSignUp } from '@/services/myapi/login';
import {
  AlipayCircleOutlined,
  LockOutlined,
  MobileOutlined,
  TaobaoCircleOutlined,
  UserOutlined,
  WeiboCircleOutlined,
} from '@ant-design/icons';
import {
  LoginForm,
  ProFormCaptcha,
  ProFormCheckbox,
  ProFormText,
} from '@ant-design/pro-components';
import { FormattedMessage, history, SelectLang, useIntl, useModel, Helmet } from '@umijs/max';
import { Alert, message, Tabs,Button, Checkbox, Form, Input } from 'antd';
import Settings from '../../../../config/defaultSettings';
import React, { useState,useEffect } from 'react';
import { flushSync } from 'react-dom';
import { createStyles } from 'antd-style';
import type { FormProps } from 'antd';
import { setToken,getToken,setAuthMenu } from "@/utils/auth";
import Routes from '../../../../config/routes';
import { filterTokenPermission} from '@/utils/authFilter';

const useStyles = createStyles(({ token }) => {
  return {
    action: {
      marginLeft: '8px',
      color: 'rgba(0, 0, 0, 0.2)',
      fontSize: '24px',
      verticalAlign: 'middle',
      cursor: 'pointer',
      transition: 'color 0.3s',
      '&:hover': {
        color: token.colorPrimaryActive,
      },
    },
    lang: {
      width: 42,
      height: 42,
      lineHeight: '42px',
      position: 'fixed',
      right: 16,
      borderRadius: token.borderRadius,
      ':hover': {
        backgroundColor: token.colorBgTextHover,
      },
    },
    homeImg:{
      width:'800px'
    },
    container: {
      display: 'flex',
      flexDirection: 'column',
      overflow: 'auto',
      height: '100vh',
      // backgroundImage:
      //   "url('https://mdn.alipayobjects.com/yuyan_qk0oxh/afts/img/V-_oS6r-i7wAAAAAAAAAAAAAFl94AQBr')",
      background:'#F9F9F9',
      // backgroundSize: '100% 100%',
    },
    innerContainer:{
      display: 'flex',
      justifyContent:'space-between',
      background:'#ffffff',
      height:'500px',
      marginTop: '23vh',
      padding:'0 200px 0 40px',
      alignItems: 'center'
    }
  };
});

type FieldType = {
  account?: string;
  password?: string;
  code?: string;
};

const ActionIcons = () => {
  const { styles } = useStyles();

  return (
    <>
      <AlipayCircleOutlined key="AlipayCircleOutlined" className={styles.action} />
      <TaobaoCircleOutlined key="TaobaoCircleOutlined" className={styles.action} />
      <WeiboCircleOutlined key="WeiboCircleOutlined" className={styles.action} />
    </>
  );
};

const Lang = () => {
  const { styles } = useStyles();

  return (
    <div className={styles.lang} data-lang>
      {SelectLang && <SelectLang />}
    </div>
  );
};

const LoginMessage: React.FC<{
  content: string;
}> = ({ content }) => {
  return (
    <Alert
      style={{
        marginBottom: 24,
      }}
      message={content}
      type="error"
      showIcon
    />
  );
};

const Login: React.FC = () => {
  const [userLoginState, setUserLoginState] = useState<API.LoginResult>({});
  const [type, setType] = useState<string>('account');
  const { initialState, setInitialState } = useModel('@@initialState');
  const { styles } = useStyles();
  const intl = useIntl();

  const [formData, setFormData] = useState({
    account:'',
    password:'',
    code:'',
  });

  const [loading,setLoading] = useState(false)

  const fetchUserInfo = async () => {
    let routes = await filterTokenPermission(Routes)
    const userInfo = await initialState?.fetchUserInfo?.();
    if (userInfo) {
      flushSync(() => {
        setInitialState((s) => ({
          ...s,
          currentUser: userInfo,
          routes
        }));
      });
    }
  };

  const onFinish: FormProps<FieldType>['onFinish'] = async(values) => {
    console.log('Success:', values);
    setLoading(true)
    try {
      // 登录
      const res = await getSignUp({ ...values });
      setTimeout(() => {
        setLoading(false)
      }, 2000);
      if(res.resultCode==0){
        const defaultLoginSuccessMessage = intl.formatMessage({
          id: 'pages.login.success',
          defaultMessage: '登录成功！',
        });
        message.success(defaultLoginSuccessMessage);
        
        // 存token、权限和用户信息
        setToken({
          accessToken:res.data.token
        })

        await setAuthMenu(res.data.authorities)
        localStorage.setItem('USER_INFO',JSON.stringify(res.data.userInfo))

        // 执行一次后currentUser有数据才能登录一次跳转
        await fetchUserInfo()
        const urlParams = new URL(window.location.href).searchParams;
        history.push(urlParams.get('redirect') || '/');

        return;
      }else{
        message.error(res.message)
      }
      // 如果失败去设置用户错误信息
      // setUserLoginState(res);
    } catch (error) {
      const defaultLoginFailureMessage = intl.formatMessage({
        id: 'pages.login.failure',
        defaultMessage: '登录失败，请重试！',
      });
      console.log(error);
      message.error(defaultLoginFailureMessage);
    }
  };
  
  const onFinishFailed: FormProps<FieldType>['onFinishFailed'] = (errorInfo) => {
    console.log('Failed:', errorInfo);
  };

  // const { status, type: loginType } = userLoginState;

  return (
    // <div className={styles.outContainer}>
    <div className={styles.container}>
      <Helmet>
        <title>
          {intl.formatMessage({
            id: 'menu.login',
            defaultMessage: '登录页',
          })}
          - {Settings.title}
        </title>
      </Helmet>
      {/* <Lang /> */}
      <div
        className={styles.innerContainer}
      >
        <div className={styles.homeImg}>
          <img src="/img/welcome.png" alt="" />
        </div>
        <div className='login-form-box'>
          <div className='head-box'>
            <div className="logo">
              <img alt="logo" src="/logo.svg" />
            </div>
            <h2>考勤管理系统</h2>
          </div>
          <Form
            name="login"
            style={{ maxWidth: 600 }}
            initialValues={{ remember: true }}
            onFinish={onFinish}
            onFinishFailed={onFinishFailed}
            autoComplete="off"
            className='login-form'
            size='large'
          >
            <Form.Item<FieldType>
              name="account"
              rules={[{ required: true, message: 'Please input your account!' }]}
              initialValue={formData.account}
            >
              <Input allowClear placeholder='用户名: admin or user' value={formData.account} key={formData.account} prefix={<UserOutlined />}/>
            </Form.Item>
            <Form.Item<FieldType>
              name="code"
              rules={[{ required: true, message: 'Please input your code!' }]}
              initialValue={formData.code}
            >
              <Input allowClear placeholder='租户代码' value={formData.code} key={formData.code} prefix={<UserOutlined />}/>
            </Form.Item>

            <Form.Item<FieldType>
              name="password"
              rules={[{ required: true, message: 'Please input your password!' }]}
              initialValue={formData.password}
              style={{marginBottom:0}}
            >
              <Input.Password allowClear placeholder='密码' value={formData.password} key={formData.password} prefix={<LockOutlined />}/>
            </Form.Item>

            <Form.Item<FieldType>
              valuePropName="checked"
              wrapperCol={{ offset: 19, span: 5 }}
              style={{marginBottom:10}}
            >
              {/* <Checkbox>Remember me</Checkbox> */}
              <a href="">忘记密码?</a>
            </Form.Item>

            <Form.Item>
              <Button type="primary" htmlType="submit" className='login-btn' disabled={loading}>
                登陆
              </Button>
            </Form.Item>
          </Form>
        </div>
      </div>
      {/* <Footer /> */}
    </div>
    // </div>
  );
};

export default Login;
