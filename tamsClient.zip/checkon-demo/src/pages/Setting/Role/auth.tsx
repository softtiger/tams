import type { FormProps } from 'antd';
import { Button, Checkbox, Form, Input,Row,Col,Tree  } from 'antd';
import React, { useState, useEffect } from 'react';
import { Alert, Card, Typography, message } from 'antd';
import type { TreeDataNode, TreeProps } from 'antd';

import {getRoleAuth,setRoleAuth} from '@/services/myapi/set';
import {generateTree} from '@/utils/createTree';

type TreeType = {
  id: number;
  level: number;
  hasPrivilege: boolean;
  menuName: string;
  parentId: number;
  children?: TreeType[];
};

const UserPsw: React.FC = (props:any) => {
  const [form] = Form.useForm();
  const [treeData, setTreeData] = useState([] as any[]);
  const [authList, setAuthList] = useState([] as any[]);
  const fieldNames = {
    title: 'menuName', 
    key: 'id', 
    children: 'children'
  }
  const getData = ()=>{
    getRoleAuth({id:props.rowData.id}).then(res=>{
      if(res.resultCode==0){
        setTreeData([...generateTree(res.data)])
        let arr = [] as TreeType[]
        res.data.map((ele:any)=>{
          if(ele.hasPrivilege)
          arr.push(ele.id) 
        })
        setAuthList([...arr])
        console.log(authList,'authList');
      }else{
        message.error(res.message)
      }
    })
  }
  const onSelect: TreeProps['onSelect'] = (selectedKeys, info) => {
    console.log('selected', selectedKeys, info);
  };

  const onCheck: TreeProps['onCheck'] = (checkedKeys, info) => {
    console.log('onCheck', checkedKeys, info);
    setAuthList([...checkedKeys])
  };

  // 提交
  const handleSubmit=()=>{
    if(authList.length>0){
      setRoleAuth({
        id:props.rowData.id,
        menuIds:authList.toString()
      }).then(res=>{
        message.success(res.message)
        handleCancel()
      })
    }else{
      message.error('请选择权限')
    }
  }
  const handleCancel=()=>{
    console.log(props);
    props.modalClose()
  }

  useEffect(() => {
    if(props.rowData.id){
      getData()
    }
    return () => {
      // console.log('组件将卸载');
    };
  }, []);


  return (
  <>
    <Row justify='start'>
      <Col>
        <Tree
          checkable
          className='my-20'
          defaultExpandParent
          checkedKeys={authList}
          onSelect={onSelect}
          onCheck={onCheck}
          treeData={treeData}
          fieldNames={fieldNames}
        />
      </Col>
    </Row>
    <div className="form-btn-box">
      <Button type="primary" className='mr-10' onClick={handleSubmit}>确定</Button>
      <Button onClick={handleCancel}>取消</Button>
    </div>
  </>
  )
};

export default UserPsw;