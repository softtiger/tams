import React, { useState, useEffect } from 'react';
import type { FormProps } from 'antd';
import { Button, Checkbox, Form, Input,Row,Col } from 'antd';
import { Alert, Card, Typography, message } from 'antd';
import {addRole,updateRole,getRole} from '@/services/myapi/set';
import BtnControl from '@/pages/BtnControl';

type FieldType = {
  code?: string;
  roleName?: string;
};

const UserAdd: React.FC = (props:any) => {
  const [form] = Form.useForm();
  const [formData, setFormData] = useState({
    id:'',
    roleName:'',
    code:'',
  });
  const onFinish: FormProps<FieldType>['onFinish'] = (values) => {
    console.log('Success:', values);
    
  };
  
  const onFinishFailed: FormProps<FieldType>['onFinishFailed'] = (errorInfo) => {
    console.log('Failed:', errorInfo);
  };

  const getData = ()=>{
    getRole({id:props.rowData.id}).then(res=>{
      if(res.resultCode==0){
        setFormData(res.data)
        form.setFieldsValue(res.data);
      }else{
        message.error(res.message)
      }
    })
  }

  const handleSubmit=()=>{
    form.validateFields().then(async val=>{
      setFormData({
        ...formData,
        ...form.getFieldsValue()
      })
      console.log(formData);
      let res
      if(!formData.id||formData.id==''){
        res = await addRole(form.getFieldsValue())
      }else{
        res = await updateRole({
          id:formData.id,
          roleName:formData.roleName,
          code:formData.code
        })
      }
      if(res.resultCode==0){
        message.success(res.message)
        props.refresh()
        handleCancel()
      }else{
        message.error(res.message)
      }
    })
  }
  const handleCancel=()=>{
    console.log(props);
    props.modalClose()
  }

  useEffect(() => {
    if(props.rowData.id){
      getData()
    }
    return () => {
      // console.log('组件将卸载');
    };
  }, []);

  return (
  <>
    <Form
      name="form"
      form={form}
      labelCol={{ span: 9}}
      wrapperCol={{ span: 16 }}
      style={{ maxWidth: 600 }}
      initialValues={{ remember: true }}
      onFinish={onFinish}
      onFinishFailed={onFinishFailed}
      autoComplete="off"
      className='modal-form'
    >
      <Row justify='space-between'>
        <Col>
          <Form.Item<FieldType>
          label="编号"
          name="code"
          rules={[{ required: true, message: '请输入编号' }]}
          >
            <Input />
          </Form.Item>
        </Col>
        <Col>
          <Form.Item<FieldType>
          label="角色名称"
          name="roleName"
          rules={[{ required: true, message: '请输入角色名称' }]}
          >
            <Input />
          </Form.Item>
        </Col>
      </Row>
    </Form>
    <div className="form-btn-box">
      <BtnControl access="/role/update"><Button type="primary" className='mr-10' onClick={handleSubmit}>确定</Button></BtnControl>
      <Button onClick={handleCancel}>取消</Button>
    </div>
  </>
  )
};

export default UserAdd;