import type { FormProps } from 'antd';
import { Button, Checkbox, Form, Input,Row,Col  } from 'antd';
import React, { useState, useEffect } from 'react';
import { Alert, Card, Typography, message } from 'antd';

import {getRoles,updateRoles} from '@/services/myapi/set';


type roleType = {
  roleId: number;
  roleName?: string;
  belongTo?: boolean;
};



const UserPsw: React.FC = (props:any) => {
  const [form] = Form.useForm();
  const [roleList, setRoleList] = useState([] as roleType[]);
  const [checklist,setChecklist] = useState([] as number[])


  // 获取列表
  const getData = async () => {
    getRoles({
      id :props.rowData.id,
    }).then(res=>{
      if(res.resultCode==0){
        setRoleList(res.data)
      }else{
        message.error(res.message)
      }
    })
  }

  // 选择角色
  const onChange = (e:any,val:roleType) =>{
    console.log(checklist,'初始状态');
    val.belongTo = e.target.checked
    console.log(val.belongTo);
    setRoleList([...roleList])
    console.log(roleList,'修改后');
    let arr = [] as number[]
    roleList.map(ele=>{
      if(ele.belongTo)
      arr.push(ele.roleId)
    })
    setChecklist(arr)
  }

  // 提交
  const handleSubmit=()=>{
    console.log(props.rowData,'props.rowData');
    
    if(checklist.length>0){
      updateRoles({
        id:props.rowData.id,
        roleIds:checklist.toString()
      }).then(res=>{
        message.success(res.message)
        handleCancel()
      })
    }else{
      message.error('请选择角色')
    }
  }
  const handleCancel=()=>{
    console.log(props);
    props.modalClose()
  }

  useEffect(() => {
    if(props.rowData.id)
    getData()
    return () => {
      // console.log('组件将卸载');
    };
  }, []);


  return (
  <>
    <Form
      name="form"
      form={form}
      wrapperCol={{ span: 24 }}
      initialValues={{ remember: true }}
      autoComplete="off"
      className='modal-form'
    >
      <Row justify='start'>
        <Col>
          <Form.Item
          name="password"
          rules={[{ required: true, message: '请选择角色' }]}
          ><>
              {roleList?.map(ele=>{
                return <Checkbox checked={ele.belongTo} onChange={(e)=>onChange(e,ele)} key={ele.id}>{ele.roleName}</Checkbox>
              })}
            </>
          </Form.Item>
        </Col>
      </Row>
    </Form>
    <div className="form-btn-box">
      <Button type="primary" className='mr-10' onClick={handleSubmit}>确定</Button>
      <Button onClick={handleCancel}>取消</Button>
    </div>
  </>
  )
};

export default UserPsw;