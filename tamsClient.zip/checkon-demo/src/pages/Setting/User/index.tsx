import React, { useState, useEffect,useRef } from 'react';
import { HeartTwoTone, SmileTwoTone } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-components';
import { useIntl } from '@umijs/max';
import { Alert, Card, Typography, message } from 'antd';
import { Button, Col, Form, Input, Row, Select, Space, theme ,Table,Pagination,Switch,Modal } from 'antd';
const { Option } = Select;
import { FormOutlined,SettingOutlined,DeleteOutlined,LockOutlined } from '@ant-design/icons';
import type { PaginationProps } from 'antd';
import type { TableProps } from 'antd';
import AddRef from './add';
import PswRef from './psw';
import RoleRef from './role';
import {getUserList,upadateStatus} from '@/services/myapi/set';
import BtnControl from '@/pages/BtnControl';

interface DataType {
  key: string;
  name: string;
  age: number;
  address: string;
  tags: string[];
}

const User: React.FC = () => {
  const intl = useIntl();
  const [form] = Form.useForm();
  const [addModal, setAddModal] = useState(false);
  const [editModal, setEditModal] = useState(false);
  const [pswModal, setPswModal] = useState(false);
  const [roleModal, setRoleModal] = useState(false);
  const [rowData, setRowData] = useState({});
  const [formData, setformData] = useState({
    userName:'',
  });
  const [data, setData] = useState([]);
  const pagination = useRef({
    total:0,
    page:1,
    pageSize: 10,
  })

  const formStyle: React.CSSProperties = {
    maxWidth: 'none',
  };

  const columns: TableProps<DataType>['columns'] = [
    {
      title: '用户名称',
      dataIndex: 'userName',
      key: 'userName',
      render: (text) => <a>{text}</a>,
    },
    {
      title: '登录账号',
      dataIndex: 'account',
      key: 'account',
    },
    {
      title: '邮箱',
      dataIndex: 'email',
      key: 'email',
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      render: (_, record) => (
        <BtnControl access="/account/toggle"><Switch checkedChildren="on" unCheckedChildren="off" defaultChecked onChange={()=>handleStatus(record)}/></BtnControl>
      ),
    },
    {
      title: '操作',
      key: 'action',
      fixed:'right',
      width:'200px',
      render: (_, record) => (
        <Space size="middle">
          <BtnControl access="/account/detail"><Button type="text" icon={<FormOutlined />} onClick={()=>handleEdit(record)}/></BtnControl>
          <BtnControl access="/account/setRoles"><Button type="text" icon={<SettingOutlined onClick={()=>handleRole(record)}/>} /></BtnControl>
          <BtnControl access="/account/setPassword"><Button type="text" icon={<LockOutlined />} onClick={()=>showPasswordModal(record)}/></BtnControl>
          {/* <Button type="text" icon={<DeleteOutlined />} onClick={()=>handleDelete(record)}/> */}
        </Space>
      ),
    },
  ];

  const onFinish = (values: any) => {
    console.log('Received values of form: ', values);
    pagination.current.page = 1
    setformData({...values})
  };

  const onShowSizeChange: PaginationProps['onShowSizeChange'] = (current, pageSize) => {
    console.log(current, pageSize);
  };
  const onPaginatingChange: PaginationProps['onShowSizeChange'] = (current, pageSize) => {
    console.log(current, pageSize);
    pagination.current.page = current
    getData()
  };
  // 打开新增窗口
  const showModal = () => {
    setRowData({})
    setAddModal(true);
  };
  // 打开密码窗口
  const showPasswordModal = (row:any) => {
    setRowData(row)
    setPswModal(true);
  };
  // 打开修改窗口
  const handleEdit = (row:any) => {
    console.log(row);
    setRowData(row)
    setEditModal(true);
  };
  // 打开配置角色窗口
  const handleRole = (row:any) => {
    setRowData(row)
    setRoleModal(true);
  };
  // 获取列表
  const getData = async () => {
    getUserList({
      userName:formData.userName,
      pageNo :pagination.current.page,
      pageSize:pagination.current.pageSize,
    }).then(res=>{
      if(res.resultCode==0){
        setData(res.data.elements)
        pagination.current.total = res.data.totalCount
      }else{
        message.error(res.message)
      }
    })
  }
  // 修改状态
  const handleStatus = (row:any) => {
    upadateStatus({
      id:row.id,
      enabled:row.status!==1
    }).then(res=>{
      if(res.resultCode==0){
        message.success(res.message)
        getData()
      }
    })
  }

  const handleOk = () => {
    setAddModal(false);
  };
  // const handleDelete = (row:any) => {
  //   if(!row.id)return
  //   Modal.confirm({
  //     title: '确认删除吗？',
  //     content: '删除后将无法恢复，请谨慎操作！',
  //     okText: '确定',
  //     okType: 'danger',
  //     cancelText: '取消',
  //     onOk() {
  //       console.log('OK');
  //     },
  //     onCancel() {
  //       console.log('Cancel');
  //     },
  //   });
  // };

  const handleCancel = () => {
    setAddModal(false);
    setEditModal(false);
    setPswModal(false);
    setRoleModal(false);
  };

  useEffect(() => {
    getData()
    return () => {
      // console.log('组件将卸载');
    };
  }, []);
  useEffect(() => {
    getData()
    return () => {
      // console.log('组件将卸载');
    };
  }, [formData]);

  return (
    <PageContainer title={false}>
      <div className="search-box bg-fff p20">
        <Form form={form} name="advanced_search" style={formStyle} layout='inline' onFinish={onFinish}>
          <BtnControl access="/account/search">
            <Form.Item name="userName">
              <Input placeholder="用户名称模糊搜索" />
            </Form.Item>
          </BtnControl>
        </Form>
        <div style={{ textAlign: 'right' }}>
          <Space size="small">
          <BtnControl access="/account/create">
            <Button type="primary" onClick={showModal}>
              新增用户
            </Button>
          </BtnControl>
          </Space>
        </div>
      </div>
      <div className="table-box">
        <Table columns={columns} dataSource={data} pagination={false} rowKey="id"/>
        <Pagination
          showSizeChanger
          onShowSizeChange={onShowSizeChange}
          defaultCurrent={1}
          total={pagination.current.total}
          pageSize={10}
          className='mt-10'
          onChange={onPaginatingChange}
        />
      </div>
      <Modal title="新增" open={addModal} onOk={handleOk} onCancel={handleCancel} width={700} footer={null} centered destroyOnClose>
        <AddRef modalClose={handleCancel} refresh={getData} rowData={rowData}/>
      </Modal>
      <Modal title="修改" open={editModal} onOk={handleOk} onCancel={handleCancel} width={700} footer={null} centered destroyOnClose>
        <AddRef modalClose={handleCancel} refresh={getData} rowData={rowData}/>
      </Modal>
      <Modal title="设置角色" open={roleModal} onOk={handleOk} onCancel={handleCancel} width={700} footer={null} centered destroyOnClose>
        <RoleRef modalClose={handleCancel} refresh={getData} rowData={rowData}/>
      </Modal>
      <Modal title="重置密码" open={pswModal} onOk={handleOk} onCancel={handleCancel} width={500} footer={null} centered destroyOnClose>
        <PswRef modalClose={handleCancel} refresh={getData} rowData={rowData}/>
      </Modal>
    </PageContainer>
  );
};

export default User;
