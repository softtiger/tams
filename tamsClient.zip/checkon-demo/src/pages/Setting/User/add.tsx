import type { FormProps } from 'antd';
import { Button, Checkbox, Form, Input,Row,Col } from 'antd';
import { Alert, Card, Typography, message } from 'antd';
import React, { useState, useEffect } from 'react';

import {addUser,getUser,updateUser} from '@/services/myapi/set';
import BtnControl from '@/pages/BtnControl';

type FieldType = {
  userName?: string;
  email?: string;
  account?: string;
  password?: string;
};

const validatePassword = (rule, value, callback) =>{
  if (!value) {
    return callback(new Error('请输入密码'));
  }
  setTimeout(() => {
    if (value.length>=6&&value.length<=12) {
      callback();
    } else {
      callback(new Error('请输入正确的密码'));
    }
  }, 100);
}
const validateEmail = (rule, value, callback) =>{
  const mailReg = /^([a-zA-Z0-9_.-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
  if (!value) {
    return callback(new Error('请输入邮箱'));
  }
  setTimeout(() => {
    if (mailReg.test(value)) {
      callback();
    } else {
      callback(new Error('请输入正确的邮箱'));
    }
  }, 100);
}

const UserAdd = (props:any) => {
  const [form] = Form.useForm();
  const [formData, setFormData] = useState({
    id:'',
    userName:'',
    email:'',
    account:'',
    password:'',
  });

  const onFinish: FormProps<FieldType>['onFinish'] = (values) => {
    console.log('Success:', values);
  };
  
  const onFinishFailed: FormProps<FieldType>['onFinishFailed'] = (errorInfo) => {
    console.log('Failed:', errorInfo);
  };

  const getData = ()=>{
    getUser({id:props.rowData.id}).then(res=>{
      if(res.resultCode==0){
        setFormData(res.data)
        form.setFieldsValue(res.data);
      }else{
        message.error(res.message)
      }
    })
  }

  // 保存
  const handleSubmit =  ()=>{
    form.validateFields().then(async val=>{
      setFormData({
        ...formData,
        ...form.getFieldsValue()
      })
      console.log(formData);
      let res
      if(!formData.id||formData.id==''){
        res = await addUser(form.getFieldsValue())
      }else{
        res = await updateUser({
          id:formData.id,
          userName:formData.userName,
          email:formData.email
        })
      }
      if(res.resultCode==0){
        message.success(res.message)
        props.refresh()
        handleCancel()
      }else{
        message.error(res.message)
      }
    })
  }
  const handleCancel=()=>{
    props.modalClose()
  }

  useEffect(() => {
    if(props.rowData.id){
      getData()
    }
    return () => {
      // console.log('组件将卸载');
    };
  }, []);


  return (
  <>
    <Form
      name="form"
      form={form}
      labelCol={{ span: 9}}
      wrapperCol={{ span: 16 }}
      style={{ maxWidth: 600 }}
      onFinish={onFinish}
      onFinishFailed={onFinishFailed}
      initialValues={{}}
      preserve={false}
      autoComplete="off"
      className='modal-form'
    >
      <Row justify='space-between'>
        <Col span={11}>
          <Form.Item<FieldType>
          label="用户名称"
          name="userName"
          rules={[{ required: true, message: '请输入用户名称' }]}
          >
            <Input />
          </Form.Item>
        </Col>
        <Col span={11}>
          <Form.Item<FieldType>
          label="登陆账号"
          name="account"
          rules={[{ required: true, message: '请输入登陆账号' }]}
          >
            <Input disabled={formData.id!==''}/>
          </Form.Item>
        </Col>
        <Col span={11}>
          <Form.Item<FieldType>
          label="邮箱"
          name="email"
          rules={[{ required: true,validator:validateEmail }]}
          >
            <Input />
          </Form.Item>
        </Col>
        <Col span={11}>
        {!formData.id&&formData.id==''? <Form.Item<FieldType>
          label="密码"
          name="password"
          rules={[{ required: true,validator:validatePassword }]}
          >
            <Input.Password/>
          </Form.Item>:null}
        </Col>
      </Row>
    </Form>
    <div className="form-btn-box">
      <BtnControl access="/account/update"><Button type="primary" className='mr-10' onClick={handleSubmit}>确定</Button></BtnControl>
      <Button onClick={handleCancel}>取消</Button>
    </div>
  </>
  )
};

export default UserAdd;