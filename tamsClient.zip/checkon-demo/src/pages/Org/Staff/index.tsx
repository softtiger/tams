import { HeartTwoTone, SmileTwoTone } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-components';
import { useIntl } from '@umijs/max';
import React, { useState, useEffect,useRef } from 'react';
import { Button, Col, Form, Input, Row, Select, Space, theme ,Table,Pagination,Switch,Modal,Drawer,Tree } from 'antd';
const { Option } = Select;
import { FormOutlined,SettingOutlined,DeleteOutlined,LockOutlined } from '@ant-design/icons';
import type { PaginationProps } from 'antd';
import { createStyles } from 'antd-style';
import type { TableProps } from 'antd';
import { Alert, Card, Typography, message } from 'antd';

import AddRef from './add';
import {getEmployeeList,getDepartmentList,getStatistics} from '@/services/myapi/org';
import {createTree} from '@/utils/createOrgTree';
import BtnControl from '@/pages/BtnControl';

interface DataType {
  key: string;
  content: string;
  age: number;
  address: string;
  tags: string[];
}

const useStyles = createStyles(({ token }) => {
  return {
    wrapper:{
      display:'flex',
    },
    left: {
      width:'250px',
      background:'#fff',
      overflow:'auto',
      padding:'15px',
      marginRight:'15px',
    },
    leftTilte:{
      fontSize:'18px',fontWeight:600,borderBottom:'1px solid #ddd',
      paddingBottom:'10px'
    },
    right:{
      flex:1,
    },
  }
})

const Staff: React.FC = () => {
  const intl = useIntl();
  const [form] = Form.useForm();
  const { styles } = useStyles();

  const [addModal, setAddModal] = useState(false);
  const [editModal, setEditModal] = useState(false);
  const [treeValue, setTreeValue] = useState([] as number[]);//选中的部门
  const [treeList, setTreeList] = useState();//部门列表
  const [treeData, setTreeData] = useState();//部门树形
  const [statisticsData, setStatisticsData] = useState({
    depart:0,
    fullTime:0,
    incumbency:0,
    partTime:0,
    trainee:0,
  });
  const [rowData, setRowData] = useState({});
  const [formData, setformData] = useState({
    content:'',
  });
  const [data, setData] = useState([]);
  const pagination = useRef({
    total:0,
    page:1,
    pageSize: 10,
  })
  const fieldNames = {
    title: 'name', 
    key: 'id', 
    children: 'children'
  }

  const formStyle: React.CSSProperties = {
    maxWidth: 'none',
  };

  const columns: TableProps<DataType>['columns'] = [
    {
      title: '编号',
      dataIndex: 'code',
      key: 'code',
    },
    {
      title: '员工姓名',
      dataIndex: 'fullname',
      key: 'fullname',
      render: (text) => <a>{text}</a>,
    },
    {
      title: '部门名称',
      dataIndex: 'orgName',
      key: 'orgName',
    },
    {
      title: '职位名称',
      dataIndex: 'positionName',
      key: 'positionName',
    },
    {
      title: '手机',
      dataIndex: 'mobile',
      key: 'mobile',
    },
    {
      title: '操作',
      key: 'action',
      fixed:'right',
      width:'200px',
      render: (_, record) => (
        <Space size="middle">
          <BtnControl access="/orgEmployee/detail">
            <Button type="text" icon={<FormOutlined />} onClick={()=>handleEdit(record)}/>
          </BtnControl>
          {/* <Button type="text" icon={<DeleteOutlined />} onClick={()=>handleDelete(record)}/> */}
        </Space>
      ),
    },
  ];

  // 搜索
  const onFinish = (values: any) => {
    console.log('Received values of form: ', values);
    pagination.current.page = 1
    setformData({...values})
  };

  const onShowSizeChange: PaginationProps['onShowSizeChange'] = (current, pageSize) => {
    console.log(current, pageSize);
  };
  // 翻页
  const onPaginatingChange: PaginationProps['onShowSizeChange'] = (current, pageSize) => {
    console.log(current, pageSize);
    pagination.current.page = current
    getData()
  };

  const showModal = () => {
    setAddModal(true);
  };
  const handleEdit = (row) => {
    console.log(row);
    setRowData(row)
    setEditModal(true);
  };

  // 员工列表
  const getData = async () => {
    getEmployeeList({
      content:formData.content,//姓名或员工编号
      orgId:treeValue.toString(),
      pageNo :pagination.current.page,
      pageSize:pagination.current.pageSize,
    }).then(res=>{
      if(res.resultCode==0){
        setData(res.data.elements)
        pagination.current.total = res.data.totalCount
      }
    })
  }
  const getStatisticsData = async () => {
    getStatistics().then(res=>{
      if(res.resultCode==0){
        setStatisticsData(res.data)
      }
    })
  }

  // 获取所有部门
  const getOrgData = ()=>{
    getDepartmentList({
      // name:formData.name,//姓名或员工编号
      pageNo :1,
      pageSize:100,
    }).then(res=>{
      if(res.resultCode==0){
        setTreeList(res.data.elements)
        let tree = createTree(res.data.elements)
        console.log(tree,'tree');
        setTreeData(tree)
      }
    })
  }
  // 选择部门
  const onTreeChange = (selectedKeys: number[], info: any) => {
    console.log(selectedKeys,'newValue');
    setTreeValue(selectedKeys)
    getData()
  };

  const handleCancel = () => {
    setAddModal(false);
    setEditModal(false);
  };

  useEffect(() => {
    getOrgData()
    getData()
    getStatisticsData()
    return () => {
      // console.log('组件将卸载');
    };
  }, []);

  useEffect(() => {
    getData()
    return () => {
      // console.log('组件将卸载');
    };
  }, [formData]);

  return (
    <PageContainer title={false}>
      <div className="wrapper">
        {/* 左侧组织树形 */}
        <div className={styles.left}>
          <h2 className={styles.leftTilte}>部门组织</h2>
          <Tree
            showLine={true}
            style={{ width: '100%' }}
            treeData={treeData}
            defaultExpandedKeys={['1']}
            onSelect={onTreeChange}
            fieldNames={fieldNames}
          />
        </div>
        {/* 右侧表格 */}
        <div className={styles.right}>
          <div className="statistics">
            <li><span>在职人数</span><b>{statisticsData.incumbency}</b></li>
            <li><span>全职人数</span><b>{statisticsData.fullTime}</b></li>
            <li><span>实习人数</span><b>{statisticsData.trainee}</b></li>
            <li><span>兼职人数</span><b>{statisticsData.partTime}</b></li>
            <li><span>离职人数</span><b>{statisticsData.depart}</b></li>
          </div>
          <div className="search-box bg-fff">
            <Form form={form} name="advanced_search" style={formStyle} layout='inline' onFinish={onFinish}>
              <BtnControl access="/orgEmployee/search">
                <Form.Item name="content">
                  <Input placeholder="员工姓名模糊搜索"/>
                </Form.Item>
              </BtnControl>
            </Form>
            <div style={{ textAlign: 'right' }}>
              <Space size="small">
                <BtnControl access="/orgEmployee/create">
                <Button type="primary" onClick={showModal}>
                  新增员工
                </Button>
                </BtnControl>
              </Space>
            </div>
          </div>
          <div className="table-box">
            <Table columns={columns} dataSource={data} pagination={false} rowKey="id"/>
            <Pagination
              showSizeChanger
              onShowSizeChange={onShowSizeChange}
              defaultCurrent={3}
              total={pagination.current.total}
              className='mt-10'
              onChange={onPaginatingChange}
            />
          </div>
        </div>
      </div>
      <Drawer title="新增" open={addModal} onClose={handleCancel} width={500} footer={null} destroyOnClose>
        <AddRef modalClose={handleCancel} refresh={getData}/>
      </Drawer>
      <Drawer title="修改" open={editModal} onClose={handleCancel} width={500} footer={null} destroyOnClose>
        <AddRef modalClose={handleCancel} refresh={getData} rowData={rowData}/>
      </Drawer>
    </PageContainer>
  );
};

export default Staff;
