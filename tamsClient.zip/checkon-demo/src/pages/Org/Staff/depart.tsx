import type { FormProps } from 'antd';
import { Button, Checkbox, Form, Input,Row,Col,Tree  } from 'antd';
import React, { useState, useEffect,useRef } from 'react';
import { Alert, Card, Typography, message } from 'antd';
import type { TreeDataNode, TreeProps } from 'antd';

import {getDepartmentList} from '@/services/myapi/org';
import {createTree} from '@/utils/createOrgTree';

type TreeType = {
  id: number;
  level: number;
  hasPrivilege: boolean;
  menuName: string;
  parentId: number;
  children?: TreeType[];
};

const Department = (props:any) => {
  const [form] = Form.useForm();
  const [treeData, setTreeData] = useState([] as any[]);
  const [authList, setAuthList] = useState([] as any[]);
  const [treeValue, setTreeValue] = useState([] as any[]);
  const checked = useRef([] as any[])
  const checkedNode = useRef({})
  const fieldNames = {
    title: 'name', 
    key: 'id', 
    children: 'children'
  }
  const getData = ()=>{
    getDepartmentList({
      pageNo :1,
      pageSize:100,
    }).then(res=>{
      if(res.resultCode==0){
        setTreeValue(res.data.elements)
        let tree = createTree(res.data.elements)
        console.log(tree,'tree');
        setTreeData(tree)
      }
    })
  }

  const onCheck = (checkedKeys, info) => {
    console.log('onCheck', checkedKeys, info);
    checked.current = info.checkedNodes
    if(checked.current.length>=2){
      let last = checked.current.pop()||''
      checked.current = [last]
    }
    // checked.current = checkedKeys?.checked
    // if(checked.current.length>=2){
    //   let last = checked.current.pop()||''
    //   checked.current = [last]
    // }
    setAuthList([checked.current[0].id])
  };

  // 提交
  const handleSubmit=()=>{
    if(authList.length>0){
      props.select(checked.current[0])
      props.modalClose()
    }else{
      message.error('请选择权限')
    }
  }
  const handleCancel=()=>{
    console.log(props);
    props.modalClose()
  }

  useEffect(() => {
    getData()
    return () => {
      // console.log('组件将卸载');
    };
  }, []);


  return (
  <>
    <Row justify='start'>
      <Col>
        <Tree
          checkable
          className='my-20'
          defaultExpandAll={true}
          checkedKeys={authList}
          onCheck={onCheck}
          treeData={treeData}
          fieldNames={fieldNames}
          checkStrictly
        />
      </Col>
    </Row>
    <div className="form-btn-box">
      <Button type="primary" className='mr-10' onClick={handleSubmit}>确定</Button>
      <Button onClick={handleCancel}>取消</Button>
    </div>
  </>
  )
};

export default Department;