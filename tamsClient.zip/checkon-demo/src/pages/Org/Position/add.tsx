import type { FormProps } from 'antd';
import { Button, Checkbox, Form, Input,Row,Col } from 'antd';
import { Alert, Card, Typography, message } from 'antd';
import React, { useState, useEffect } from 'react';

import {addPosition,getPosition,updatePosition} from '@/services/myapi/org';
import BtnControl from '@/pages/BtnControl';

type FieldType = {
  code?: string;
  name?: string;
  id?: number;
  status?: boolean;
};

const validateInput = (rule, value, callback) =>{
  let pattern = /^[0-9]+$/
  if (!value) {
    return callback(new Error('请输入编号'));
  }
  setTimeout(() => {
    if (value.length >= 3 && value.length <= 6 && pattern.test(value)) {
      callback();
    } else {
      callback(new Error('请输入3-6个字符的编号'));
    }
  }, 100);
}
const validateInput2 = (rule, value, callback) =>{
  if (!value) {
    return callback(new Error('请输入姓名'));
  }
  setTimeout(() => {
    if (value.length >=2 && value.length <= 20) {
      callback();
    } else {
      callback(new Error('请输入2-20个字符的职位名称'));
    }
  }, 100);
}

const UserAdd: React.FC = (props:any) => {
  const [form] = Form.useForm();
  const [formData, setFormData] = useState({
    id:'',
    name:'',
    status:'',
    code:'',
  });

  const onFinish: FormProps<FieldType>['onFinish'] = (values) => {
    console.log('Success:', values);
  };
  
  const onFinishFailed: FormProps<FieldType>['onFinishFailed'] = (errorInfo) => {
    console.log('Failed:', errorInfo);
  };

  const getData = ()=>{
    getPosition({id:props.rowData.id}).then(res=>{
      if(res.resultCode==0){
        setFormData(res.data)
        form.setFieldsValue(res.data);
      }else{
        message.error(res.message)
      }
    })
  }

  // 保存
  const handleSubmit =  ()=>{
    form.validateFields().then(async val=>{
      setFormData({
        ...formData,
        ...form.getFieldsValue()
      })
      console.log(formData);
      let res
      if(!formData.id||formData.id==''){
        res = await addPosition({
          ...form.getFieldsValue(),
          status:true
        })
      }else{
        res = await updatePosition({
          id:formData.id,
          name:formData.name,
          code:formData.code,
        })
      }
      if(res.resultCode==0){
        message.success(res.message)
        props.refresh()
        handleCancel()
      }else{
        message.error(res.message)
      }
    })
  }
  const handleCancel=()=>{
    props.modalClose()
  }

  useEffect(() => {
    if(props.rowData?.id){
      getData()
    }
    return () => {
      // console.log('组件将卸载');
    };
  }, []);


  return (
  <>
    <Form
      name="form"
      form={form}
      labelCol={{ span: 9}}
      wrapperCol={{ span: 16 }}
      style={{ maxWidth: 600 }}
      onFinish={onFinish}
      onFinishFailed={onFinishFailed}
      initialValues={{}}
      preserve={false}
      autoComplete="off"
      className='modal-form'
    >
      <Row justify='space-between'>
        <Col span={11}>
          <Form.Item<FieldType>
          label="编号"
          name="code"
          rules={[{ required: true, validator:validateInput }]}
          >
            <Input/>
          </Form.Item>
        </Col>
        <Col span={11}>
          <Form.Item<FieldType>
          label="职位名称"
          name="name"
          rules={[{ required: true, validator:validateInput2 }]}
          >
            <Input />
          </Form.Item>
        </Col>
      </Row>
    </Form>
    <div className="form-btn-box">
      <BtnControl access="/orgPosition/update"><Button type="primary" className='mr-10' onClick={handleSubmit}>确定</Button></BtnControl>
      <Button onClick={handleCancel}>取消</Button>
    </div>
  </>
  )
};

export default UserAdd;