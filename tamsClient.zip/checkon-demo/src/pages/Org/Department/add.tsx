import type { FormProps } from 'antd';
import { Button, Checkbox, Form, Input,Row,Col,TreeSelect,Select  } from 'antd';
import { Alert, Card, Typography, message } from 'antd';
import React, { useState, useEffect } from 'react';

import {getDepartmentList,getDepartment,addDepartment,updateDepartment} from '@/services/myapi/org';
import {createTree} from '@/utils/createOrgTree';
import BtnControl from '@/pages/BtnControl';

type FieldType = {
  name?: string;
  type?: string;
  parentOrg?: string;
  code?: string;
};

const validateInput = (rule, value, callback) =>{
  let pattern = /^[0-9]+$/
  if (!value) {
    return callback(new Error('请输入编号'));
  }
  setTimeout(() => {
    if (value.length >= 3 && value.length <= 6 && pattern.test(value)) {
      callback();
    } else {
      callback(new Error('请输入3-6个字符的编号'));
    }
  }, 100);
}
const validateInput2 = (rule, value, callback) =>{
  if (!value) {
    return callback(new Error('请输入部门名称'));
  }
  setTimeout(() => {
    if (value.length >=3 && value.length <= 20) {
      callback();
    } else {
      callback(new Error('请输入3-20个字符的名称'));
    }
  }, 100);
}


const UserAdd: React.FC = (props:any) => {
  const [form] = Form.useForm();
  const fieldNames = {
    label: 'name', 
    value: 'id', 
    children: 'children'
  }
  const [formData, setFormData] = useState({
    id:'',
    name:'',
    type:1,//1 企业 2子公司 3部门
    parentOrg:'',
    code:'',
  });
  const [treeValue, setTreeValue] = useState([] as any[]);
  const [treeData, setTreeData] = useState([] as any[]);

  const validateParent = (rule, value, callback) =>{
    let type = form.getFieldValue('type')
    if (!value && type==1) {
      return callback();
    }
    setTimeout(() => {
      if (type!==1 && (!value||value=='')) {
        callback(new Error('请选择上级部门'));
      } else {
        callback();
      }
    }, 100);
  }

  const onFinish: FormProps<FieldType>['onFinish'] = (values) => {
    console.log('Success:', values);
  };
  
  const onFinishFailed: FormProps<FieldType>['onFinishFailed'] = (errorInfo) => {
    console.log('Failed:', errorInfo);
  };
  // 获取部门信息
  const getData = ()=>{
    getDepartment({id:props.rowData.id}).then(res=>{
      if(res.resultCode==0){
        setFormData(res.data)
        form.setFieldsValue(res.data);
      }else{
        message.error(res.message)
      }
    })
  }
  // 获取所有部门
  const getOrgData = ()=>{
    getDepartmentList({
      pageNo :1,
      pageSize:100,
    }).then(res=>{
      if(res.resultCode==0){
        setTreeValue(res.data.elements)
        let tree = createTree(res.data.elements)
        console.log(tree,'tree');
        setTreeData(tree)
      }
    })
  }
  // 选择上级
  const onTreeChange = (newValue: string) => {
    console.log(newValue,'newValue');
    let cur = treeValue.find(ele=>ele.id==newValue)
    setFormData({
      ...form.getFieldsValue(),
      parentOrg:newValue,
      type: cur?cur.type+1:null
    });
  };
  const onChange = (newValue: string) => {
    setFormData({
      ...form.getFieldsValue(),
    });
    return 
  };


  // 保存
  const handleSubmit =  ()=>{
    form.validateFields().then(async val=>{
      setFormData({
        ...form.getFieldsValue()
      })
      console.log(formData);
      
      let res
      if(!props.rowData?.id||props.rowData?.id==''){
        res = await addDepartment(formData)
      }else{
        res = await updateDepartment({
          id:props.rowData?.id,
          name:formData.name,
          parentOrg:formData.parentOrg,
          code:formData.code,
          type:formData.type,
        })
      }
      if(res.resultCode==0){
        message.success(res.message)
        props.refresh()
        handleCancel()
      }else{
        message.error(res.message)
      }
    })
  }
  const handleCancel=()=>{
    props.modalClose()
  }

  useEffect(() => {
    getOrgData()
    if(props.rowData?.id){
      getData()
    }
    return () => {
      // console.log('组件将卸载');
    };
  }, []);


  return (
  <>
    <Form
      name="form"
      form={form}
      labelCol={{ span: 9}}
      wrapperCol={{ span: 16 }}
      style={{ maxWidth: 600 }}
      onFinish={onFinish}
      onFinishFailed={onFinishFailed}
      initialValues={{}}
      preserve={false}
      autoComplete="off"
      className='modal-form'
    >
      <Row justify='space-between'>
        <Col span={11}>
          <Form.Item<FieldType>
          label="编号"
          name="code"
          rules={[{ required: true, validator:validateInput }]}
          >
            <Input onChange={onChange}/>
          </Form.Item>
        </Col>
        <Col span={11}>
          <Form.Item<FieldType>
          label="部门名称"
          name="name"
          rules={[{ required: true, validator:validateInput2 }]}
          >
            <Input onChange={onChange}/>
          </Form.Item>
        </Col>
        <Col span={11}>
          <Form.Item<FieldType>
          label="部门类型"
          name="type"
          initialValue={1}
          rules={[{ required: true, message: '请输入部门类型' }]}
          >
            <Select
              allowClear
              onChange={onChange}
              options={[
                { value: 1, label: '一级企业' },
                { value: 2, label: '二级企业' },
                { value: 3, label: '部门' },
              ]}
            />
          </Form.Item>
        </Col>
        <Col span={11}>
          <Form.Item<FieldType>
          label="上级部门"
          name="parentOrg"
          style={{width:'100%'}}
          rules={[{ required: false,validator:validateParent }]}
          >
            <TreeSelect
              showSearch
              treeLine={true}
              allowClear
              style={{ width: '100%' }}
              value={formData.parentOrg}
              dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
              treeData={treeData}
              placeholder="请选择上级部门"
              treeDefaultExpandAll
              onChange={onTreeChange}
              fieldNames={fieldNames}
            />
          </Form.Item>
        </Col>
      </Row>
    </Form>
    <div className="form-btn-box">
      <BtnControl access="/org/update"><Button type="primary" className='mr-10' onClick={handleSubmit}>确定</Button></BtnControl>
      <Button onClick={handleCancel}>取消</Button>
    </div>
  </>
  )
};

export default UserAdd;