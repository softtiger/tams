// @ts-ignore
/* eslint-disable */
// API 更新时间：
// API 唯一标识：
import * as set from './set';
import * as login from './login';
export default {
  set,
  login,
};
