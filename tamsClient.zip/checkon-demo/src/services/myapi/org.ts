// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** 查询职位 */
export async function getPositionList(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/orgPosition/search', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

/** 新增职位 */
export async function addPosition(data:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/orgPosition/create', {
    method: 'PUT',
    data,
    ...(options || {}),
  });
}
/** 查询职位 */
export async function getPosition(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/orgPosition/detail', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
/** 修改职位 */
export async function updatePosition(data:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/orgPosition/update', {
    method: 'PUT',
    data,
    ...(options || {}),
  });
}
/** 修改状态 */
export async function upadatePositionStatus(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/orgPosition/toggle', {
    method: 'POST',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}



/** 查询部门 */
export async function getDepartmentList(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/org/search', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

/** 新增部门 */
export async function addDepartment(data:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/org/create', {
    method: 'PUT',
    data,
    ...(options || {}),
  });
}
/** 查询部门 */
export async function getDepartment(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/org/detail', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
/** 修改部门 */
export async function updateDepartment(data:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/org/update', {
    method: 'POST',
    data,
    ...(options || {}),
  });
}
/** 修改状态 */
export async function upadateDepartmentStatus(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/org/toggle', {
    method: 'POST',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}


/** 查询员工 */
export async function getEmployeeList(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/orgEmployee/search', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

/** 新增员工 */
export async function addEmployee(data:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/orgEmployee/create', {
    method: 'PUT',
    data,
    ...(options || {}),
  });
}
/** 查询员工 */
export async function getEmployee(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/orgEmployee/detail', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
/** 修改员工 */
export async function updateEmployee(data:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/orgEmployee/update', {
    method: 'POST',
    data,
    ...(options || {}),
  });
}
/** 员工统计 */
export async function getStatistics(params?:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/orgEmployee/statistics', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}



























/** 查询角色 */
export async function getRoleList(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/role/search', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}


/** 登录 */
export async function getSignUp(
  params: {
    // query
    account?: string;
    code?: string;
    password?: string;
  },
  options?: { [key: string]: any },
) {
  return request<API.Result>('/account/login', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}













/** 退出登录接口 POST /api/login/outLogin */
export async function outLogin(options?: { [key: string]: any }) {
  return request<Record<string, any>>('/api/login/outLogin', {
    method: 'POST',
    ...(options || {}),
  });
}

/** 登录接口 POST /api/login/account */
export async function login(body: API.LoginParams, options?: { [key: string]: any }) {
  return request<API.LoginResult>('/api/login/account', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 GET /api/notices */
export async function getNotices(options?: { [key: string]: any }) {
  return request<API.NoticeIconList>('/api/notices', {
    method: 'GET',
    ...(options || {}),
  });
}

/** 获取规则列表 GET /api/rule */
export async function rule(
  params: {
    // query
    /** 当前的页码 */
    current?: number;
    /** 页面的容量 */
    pageSize?: number;
  },
  options?: { [key: string]: any },
) {
  return request<API.RuleList>('/api/rule', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

/** 更新规则 PUT /api/rule */
export async function updateRule(options?: { [key: string]: any }) {
  return request<API.RuleListItem>('/api/rule', {
    method: 'POST',
    data:{
      method: 'update',
      ...(options || {}),
    }
  });
}

/** 新建规则 POST /api/rule */
export async function addRule(options?: { [key: string]: any }) {
  return request<API.RuleListItem>('/api/rule', {
    method: 'POST',
    data:{
      method: 'post',
      ...(options || {}),
    }
  });
}

/** 删除规则 DELETE /api/rule */
export async function removeRule(options?: { [key: string]: any }) {
  return request<Record<string, any>>('/api/rule', {
    method: 'POST',
    data:{
      method: 'delete',
      ...(options || {}),
    }
  });
}
