// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** 登录 */
export async function getSignUp(
  params: {
    // query
    account?: string;
    code?: string;
    password?: string;
  },
  options?: { [key: string]: any },
) {
  return request<API.Result>('/account/login', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

/** 退出登录 */
export async function getLogout(
  params:object,
  options?: { [key: string]: any },
) {
  return request<API.Result>('/account/logout', {
    method: 'POST',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

