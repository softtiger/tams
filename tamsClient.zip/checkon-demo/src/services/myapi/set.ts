// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** 查询用户列表 */
export async function getUserList(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/account/search', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
/** 新增用户 */
export async function addUser(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/account/create', {
    method: 'POST',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
/** 查询用户 */
export async function getUser(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/account/detail', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
/** 修改用户 */
export async function updateUser(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/account/update', {
    method: 'PUT',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
/** 修改密码 */
export async function upadatePassword(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/account/setPassword', {
    method: 'PUT',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
/** 修改状态 */
export async function upadateStatus(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/account/toggle', {
    method: 'PUT',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
/** 查看用户配置的角色 */
export async function getRoles(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/account/getRoles', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
/** 为指定用户配置角色 */
export async function updateRoles(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/account/setRoles', {
    method: 'PUT',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}





/** 查询角色列表 */
export async function getRoleList(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/role/search', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
/** 新增角色 */
export async function addRole(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/role/create', {
    method: 'POST',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
/** 查询角色 */
export async function getRole(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/role/detail', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
/** 修改角色 */
export async function updateRole(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/role/update', {
    method: 'PUT',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
/** 修改状态 */
export async function upadateRoleStatus(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/role/toggle', {
    method: 'PUT',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

/** 查看角色权限 */
export async function getRoleAuth(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/role/getPrivileges', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
/** 设置角色权限 */
export async function setRoleAuth(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/role/setPrivileges', {
    method: 'PUT',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

/** 查询租户信息 */
export async function getTenantList(params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>('/tenant/search', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}









/** 退出登录接口 POST /api/login/outLogin */
export async function outLogin(options?: { [key: string]: any }) {
  return request<Record<string, any>>('/api/login/outLogin', {
    method: 'POST',
    ...(options || {}),
  });
}

/** 登录接口 POST /api/login/account */
export async function login(body: API.LoginParams, options?: { [key: string]: any }) {
  return request<API.LoginResult>('/api/login/account', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 GET /api/notices */
export async function getNotices(options?: { [key: string]: any }) {
  return request<API.NoticeIconList>('/api/notices', {
    method: 'GET',
    ...(options || {}),
  });
}

/** 获取规则列表 GET /api/rule */
export async function rule(
  params: {
    // query
    /** 当前的页码 */
    current?: number;
    /** 页面的容量 */
    pageSize?: number;
  },
  options?: { [key: string]: any },
) {
  return request<API.RuleList>('/api/rule', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

/** 更新规则 PUT /api/rule */
export async function updateRule(options?: { [key: string]: any }) {
  return request<API.RuleListItem>('/api/rule', {
    method: 'POST',
    data:{
      method: 'update',
      ...(options || {}),
    }
  });
}

/** 新建规则 POST /api/rule */
export async function addRule(options?: { [key: string]: any }) {
  return request<API.RuleListItem>('/api/rule', {
    method: 'POST',
    data:{
      method: 'post',
      ...(options || {}),
    }
  });
}

/** 删除规则 DELETE /api/rule */
export async function removeRule(options?: { [key: string]: any }) {
  return request<Record<string, any>>('/api/rule', {
    method: 'POST',
    data:{
      method: 'delete',
      ...(options || {}),
    }
  });
}
