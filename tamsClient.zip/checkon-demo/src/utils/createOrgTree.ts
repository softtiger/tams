interface TreeNode {
    id: number;
    type: number;
    name: string;
    parentOrg: number;
    children?: TreeNode[];
  }
  
  export function createTree(arr: TreeNode[]): TreeNode[] {
    const tree: TreeNode[] = [];
    console.log(arr,'arr');
    
    for (let i = 0; i < arr.length; i++) {
      const item = arr[i];
      if (item.type === 1) {
        tree.push(item);
      } else {
        const parent = findParent(arr, item.parentOrg);
        if (parent !== null) {
          if (!parent.children) {
            parent.children = [];
          }
          parent.children.push(item);
        }
      }
    }
    return tree;
  }
  
  function findParent(arr: TreeNode[], parentOrg: number): TreeNode | null {
    for (let i = 0; i < arr.length; i++) {
      const item = arr[i];
      
      if (item.id === parentOrg) {
        return item;
      } else if (item.children) {
        const parent = findParent(item.children, parentOrg);
        if (parent !== null) {
          return parent;
        }
      }
    }
    return null;
  }
  