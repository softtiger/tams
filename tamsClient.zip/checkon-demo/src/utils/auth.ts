import Cookies from "js-cookie";

export interface DataInfo<T> {
    /** token */
    accessToken: string;
    /** `accessToken`的过期时间（时间戳） */
    expires: T;
    /** 用于调用刷新accessToken的接口时所需的token */
    refreshToken: string;
    /** 用户名 */
    username?: string;
    /** 公司名 */
    companyName?: string;
    id?: string;
    /** 当前登陆用户的角色 */
    roles?: Array<string>;
}

export const sessionKey = "USER_INFO";
export const TokenKey = "authorized-token";
export const AuthKey = "authorized-navgation";

/** 获取`token` */
export function getToken(){
    // 此处与`TokenKey`相同，此写法解决初始化时`Cookies`中不存在`TokenKey`报错
    return Cookies.get(TokenKey)
      ? JSON.parse(Cookies.get(TokenKey))
      : localStorage.getItem(TokenKey);
}

/** 储存`token` */
export function setToken(data:any) {
  let expires = 0;
  const { accessToken, refreshToken } = data;
  expires = new Date(data.expires).getTime(); // 如果后端直接设置时间戳，将此处代码改为expires = data.expires，然后把上面的DataInfo<Date>改成DataInfo<number>即可
  const cookieString = JSON.stringify({ accessToken, expires });

  expires > 0
    ? Cookies.set(TokenKey, cookieString, {
        expires: (expires - Date.now()) / 86400000
      })
    : Cookies.set(TokenKey, cookieString);
  
  // 如果有状态管理，下面再存入状态管理
}

/** 储存权限菜单 */
export function setAuthMenu(data:any) {
  localStorage.setItem(AuthKey,JSON.stringify(data))
}

/** 获取权限菜单 */
export function getAuthMenu(data:any) {
  const menu = localStorage.getItem(AuthKey)||''
  return JSON.parse(menu)
}


/** 删除`token`以及key值为`user-info`的session信息 */
export function removeToken() {
    Cookies.remove(TokenKey);
    localStorage.clear()
    sessionStorage.clear();
}
