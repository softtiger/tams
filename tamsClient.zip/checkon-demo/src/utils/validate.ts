import { $t, transformI18n } from "@/plugins/i18n";

export const validateEmail = (rule, value, callback) =>{
    const mailReg = /^([a-zA-Z0-9_.-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
    if (!value) {
      return callback(new Error('请输入邮箱'));
    }
    setTimeout(() => {
      if (mailReg.test(value)) {
        callback();
      } else {
        callback(new Error('请输入正确的邮箱'));
      }
    }, 100);
  }


  export const validatePassword = (rule, value, callback) =>{
    if (!value) {
      return callback(new Error('请输入密码'));
    }
    setTimeout(() => {
      if (value.length>=6&&value.length<=12) {
        callback();
      } else {
        callback(new Error('请输入正确的密码'));
      }
    }, 100);
  }