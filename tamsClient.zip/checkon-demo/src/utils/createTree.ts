  interface TreeNode {
    id: number;
    level: number;
    hasPrivilege: boolean;
    menuName: string;
    parentId: number;
    children?: TreeNode[];
  }
  
  export function generateTree(arr: TreeNode[]): TreeNode[] {
    const tree: TreeNode[] = [];
    for (let i = 0; i < arr.length; i++) {
      const item = arr[i];
      if (item.level === 1) {
        tree.push(item);
      } else {
        const parent = findParent(tree, item.parentId);
        if (parent !== null) {
          if (!parent.children) {
            parent.children = [];
          }
          parent.children.push(item);
        }
      }
    }
    return tree;
  }
  
  function findParent(arr: TreeNode[], parentId: number): TreeNode | null {
    for (let i = 0; i < arr.length; i++) {
      const item = arr[i];
      
      if (item.id === parentId) {
        return item;
      } else if (item.children) {
        const parent = findParent(item.children, parentId);
        if (parent !== null) {
          return parent;
        }
      }
    }
    return null;
  }
  