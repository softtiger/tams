import { post,get,put,del } from './http';

type RecordType={
  startDate:string;
  endDate:string;
  pageNo:number;
  pageSize:number;
  employeeId:number|string;
}

/** 打卡记录控制器 */

// 查询打卡记录
export function getRecordList(params:RecordType){
  return get('/attendanceRecord/search', params);
}

// 导出打卡记录
export function exportRecord(params:RecordType){
  return get('/attendanceRecord/export', params);
}


/** 考勤汇总控制器 */

// 考勤汇总查询
export function getCheckInList(params:RecordType){
  return get('/attendanceStatistics/search', params);
}

// 导出
export function exportCheckIn(params:RecordType){
  return get('/attendanceStatistics/export', params);
}


// 首页统计
export function getHome(params:{date:string}){
  return get('/home', params);
}































