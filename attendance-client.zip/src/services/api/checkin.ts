import { post,get,put,del } from './http';

/** 排班表控制器 */

// 查询排班
export function getScheduleList(params:API.searchListType){
  return get('/schedule/search', params);
}

// 新增排班
export function addSchedule(params:object){
  return post('/schedule/create', params);
}
// id查询排班
export function getSchedule(params:{id:string}){
  return get('/schedule/detail', params);
}
// 修改排班
export function updateSchedule(params:object){
  return put('/schedule/update', params);
}
// 删除
export function delSchedule(params:{id:string}){
  return del('/schedule/remove', params);
}


/** 考勤组控制器 */

// 查询考勤组
export function getAttendanceGroupList(params:API.searchListType){
  return get('/attendanceGroup/search', params);
}

// 新增考勤组
export function addAttendanceGroup(params:object){
  return post('/attendanceGroup/create', params);
}
// id查询考勤组
export function getAttendanceGroup(params:{id:string}){
  return get('/attendanceGroup/detail', params);
}
// 修改考勤组
export function updateAttendanceGroup(params:object){
  return put('/attendanceGroup/update', params);
}
// 删除
export function delAttendanceGroup(params:{id:string}){
  return del('/attendanceGroup/remove', params);
}










