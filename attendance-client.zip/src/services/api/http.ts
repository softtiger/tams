import { request } from '@umijs/max';

export async function post(url:string,params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>(url, {
    method: 'POST',
    data:{ ...params},
    ...(options || {}),
  });
}
export async function postParams(url:string,params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>(url, {
    method: 'POST',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
export async function get(url:string,params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>(url, {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
export async function putParams(url:string,params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>(url, {
    method: 'PUT',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
export async function put(url:string,params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>(url, {
    method: 'PUT',
    data: {
      ...params,
    },
    ...(options || {}),
  });
}
export async function del(url:string,params:object,
  options?: { [key: string]: any }) {
  return request<API.Result>(url, {
    method: 'DELETE',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
