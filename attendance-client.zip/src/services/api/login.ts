// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';
import { post,get,put,del, postParams } from './http';

export function getSignUp(params:object){
  return get('/account/login', params);
}
export function getLogout(params:object){
  return postParams('/account/logout', params);
}


