import { post,get,put,del,postParams,putParams } from './http';

/** 查询职位 */
export function getPositionList(params:API.searchListType){
  return get('/orgPosition/search', params);
}

/** 新增职位 */
export function addPosition(params:{
  name:string;
  id :string;
  code:string;
  status:boolean;
}){
  return put('/orgPosition/create', params);
}
/** 查询职位 */
export function getPosition(params:{id:string}){
  return get('/orgPosition/detail', params);
}
/** 修改职位 */
export function updatePosition(data:object){
  return put('/orgPosition/update', data);
}
/** 修改状态 */
export function upadatePositionStatus(params:object){
  return postParams('/orgPosition/toggle', params);
}


/** 查询部门 */
export function getDepartmentList(params:API.searchListType){
    return get('/org/search', params);
}

/** 新增部门 */
export function addDepartment(params:{
  name:string;
  id :string;
  code:string;
  leaveTime:string;
  employeeId:string;
  status:boolean;
}){
  return put('/org/create', params);
}
/** 查询部门 */
export function getDepartment(params:{id:string}){
  return get('/org/detail', params);
}
/** 修改部门 */
export function updateDepartment(data:object){
  return post('/org/update', data);
}
/** 修改状态 */
export function upadateDepartmentStatus(params:object){
  return postParams('/org/toggle', params);
}



/** 查询员工 */
export function getEmployeeList(params:API.searchListType){
    return get('/orgEmployee/search', params);
}
/** 新增员工 */
export function addEmployee(params:object){
  return put('/orgEmployee/create', params);
}
/** 查询员工 */
export function getEmployee(params:{id:string}){
  return get('/orgEmployee/detail', params);
}
/** 修改员工 */
export function updateEmployee(data:object){
  return post('/orgEmployee/update', data);
}
/** 员工统计 */
export function getStatistics(){
  return get('/orgEmployee/statistics',{});
}




/** 查询离职 */
export function getDepartList(params:API.searchListType){
  return get('/orgDepart/search', params);
}
/** 新增离职 */
export function addDepart(params:{
  name:string;
  id :string;
  code?:string;
  status:number;
  employeeId:string;
}){
  return put('/orgDepart/create', params);
}
/** id查询离职 */
export function getDepart(params:{id:string}){
  return get('/orgDepart/detail', params);
}
/** 修改离职 */
export function updateDepart(data:object){
  return post('/orgDepart/update', data);
}
/** 确认离职 */
export function confirmDepart(data:object){
  return post('/orgDepart/confirm', data);
}
































