import { post,get,put,del,postParams,putParams } from './http';

/** 查询用户列表 */
export function getUserList(params:API.searchListType){
  return get('/account/search', params);
}
/** 新增用户 */
export function addUser(params:{
  account:string;
  email :string;
  password:string;
  userName :string;
}){
  return postParams('/account/create', params);
}
/** 查询用户 */
export function getUser(params:object){
  return get('/account/detail', params);
}
/** 修改用户 */
export function updateUser(params:object){
  return putParams('/account/update', params);
}
/** 修改密码 */
export function upadatePassword(params:object){
  return putParams('/account/setPassword', params);
}
/** 修改状态 */
export function upadateStatus(params:object){
  return putParams('/account/toggle', params);
}
/** 查看用户配置的角色 */
export function getRoles(params:object){
  return get('/account/getRoles', params);
}
/** 为指定用户配置角色 */
export function updateRoles(params:object){
  return putParams('/account/setRoles', params);
}
  
  
  
/** 查询角色列表 */
export function getRoleList(params:API.searchListType){
  return get('/role/search', params);
}
/** 新增角色 */
export function addRole(params:object){
  return postParams('/role/create', params);
}
/** 查询角色 */
export function getRole(params:object){
  return get('/role/detail', params);
}
/** 修改角色 */
export function updateRole(params:{id:string}){
  return putParams('/role/update', params);
}
/** 修改状态 */
export function upadateRoleStatus(params:object){
  return putParams('/role/toggle', params);
}
/** 查看角色权限 */
export function getRoleAuth(params:object){
  return get('/role/getPrivileges', params);
}
/** 设置角色权限 */
export function setRoleAuth(params:object){
  return putParams('/role/setPrivileges', params);
}



/** 查询租户列表 */
export function getTenantList(params:API.searchListType){
  return get('/tenant/search', params);
}