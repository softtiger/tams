import {
  LockOutlined,
  UserOutlined,
} from '@ant-design/icons';
import { FormattedMessage, history, SelectLang, useIntl, useModel, Helmet } from '@umijs/max';
import { Alert, message, Tabs,Button, Checkbox, Form, Input } from 'antd';
import Settings from '../../../../config/defaultSettings';
import React, { useState,useEffect } from 'react';
import { flushSync } from 'react-dom';
import { createStyles } from 'antd-style';
import type { FormProps } from 'antd';
import style from './login.module.less'
import Routes from '../../../../config/routes';
import { setToken,getToken,setAuthMenu,setInfo } from "@/utils/auth";
import { getSignUp } from '@/services/api/login';
import { filterTokenPermission} from '@/utils/authFilter';


type FieldType = {
  account?: string;
  password?: string;
  code?: string;
};

const Login: React.FC = () => {
  const { initialState, setInitialState } = useModel('@@initialState');
  const [formData, setFormData] = useState({
    account:'',
    password:'',
    code:'000',
  });

  const [loading,setLoading] = useState(false)

  const fetchUserInfo = async () => {
    let routes = await filterTokenPermission(Routes) as unknown as API.Router_Type
    const userInfo = await initialState?.fetchUserInfo?.();
    if (userInfo) {
      flushSync(() => {
        setInitialState((s) => ({
          ...s,
          routes,
          currentUser: userInfo,
        }));
      });
    }
  };

  const onFinish: FormProps<FieldType>['onFinish'] = async(values) => {
    console.log('Success:', values);
    setLoading(true)
    try {
      // 登录
      const res = await getSignUp({ ...values });
      setTimeout(() => {
        setLoading(false)
      }, 2000);
      if(res.resultCode==0){
        message.success('登录成功！');
        
        // 存token、权限和用户信息
        setToken({
          accessToken:res.data.token
        })

        await setAuthMenu(res.data.authorities)
        setInfo(res.data.userInfo)
        // 执行一次后currentUser有数据才能登录一次跳转
        await fetchUserInfo()
        const urlParams = new URL(window.location.href).searchParams;
        history.push(urlParams.get('redirect') || '/');

        return;
      }else{
        message.error(res.message)
      }
    } catch (error) {
      message.error('登录失败，请重试！');
    }
  };
  
  const onFinishFailed: FormProps<FieldType>['onFinishFailed'] = (errorInfo) => {
    console.log('Failed:', errorInfo);
  };

  return (
    <div className={style.container}>
      <Helmet>
        <title>
          登录 - {Settings.title}
        </title>
      </Helmet>
      <div className={style.innerContainer}>
      <div className={style.homeImg}>
          <img src="/img/welcome.png" alt="" />
        </div>
        <div className={style.loginFormBox}>
          <div className={style.headBox}>
            <div className={style.logo}>
              <img alt="logo" src="/logo.svg" />
            </div>
            <h2>考勤管理系统</h2>
          </div>
          <Form
            name="basic"
            style={{ maxWidth: 600 }}
            onFinish={onFinish}
            onFinishFailed={onFinishFailed}
            autoComplete="off"
            className={style.loginForm}
            size='large'
          >
            <Form.Item<FieldType>
              name="account"
              rules={[{ required: true, message: 'Please input your account!' }]}
              initialValue={formData.account}
            >
              <Input placeholder='账户' value={formData.account} prefix={<UserOutlined />}/>
            </Form.Item>
            <Form.Item<FieldType>
              name="code"
              rules={[{ required: true, message: 'Please input your code!' }]}
              initialValue={formData.code}
            >
              <Input placeholder='租户代码' prefix={<UserOutlined />}/>
            </Form.Item>

            <Form.Item<FieldType>
              name="password"
              rules={[{ required: true, message: 'Please input your password!' }]}
              initialValue={formData.password}
            >
              <Input.Password placeholder='密码' prefix={<LockOutlined />}/>
            </Form.Item>
            <Form.Item>
              <Button type="primary" htmlType="submit" className={style.loginBtn} disabled={loading}>
                登录
              </Button>
            </Form.Item>
          </Form>
        </div>
      </div>
      </div>
  );
};

export default Login;
