import type { FormProps } from 'antd';
import { Button, Checkbox, Form, Input,Row,Col,Table,Select,Flex,DatePicker,Space,InputNumber  } from 'antd';
import { Alert, Card, Typography, message } from 'antd';
import React, { useState, useEffect,useRef,useCallback,useMemo } from 'react';
import {LeftOutlined,RightOutlined,DeleteOutlined} from '@ant-design/icons';
import type { TableProps } from 'antd';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import {getAttendanceGroupList,getAttendanceGroup} from '@/services/api/checkin';
import {calMinutes,calHours} from '@/utils/calminute';
import BtnControl from '@/pages/BtnControl';
import dayjs, { Dayjs } from 'dayjs'
import duration from 'dayjs/plugin/duration';
import { createStyles } from 'antd-style';
import { getHome } from '@/services/api/statistics';
import { getAllDatesOfMonth } from '@/utils/getMonthDay';
import axios from "axios";
dayjs.extend(duration);
const localizer = dayjsLocalizer (dayjs)
import { Calendar, dayjsLocalizer  } from 'react-big-calendar'
import 'react-big-calendar/lib/css/react-big-calendar.css';

import logo from '../../../public/img/u278.svg'
import logo2 from '../../../public/img/u289.svg'
import logo3 from '../../../public/img/u294.svg'
import logo4 from '../../../public/img/u300.svg'
import logo5 from '../../../public/img/u307.svg'

import icon1 from '../../../public/img/u472.svg'
import icon2 from '../../../public/img/u478.svg'
import icon3 from '../../../public/img/u482.svg'


const useStyles = createStyles(({ token }) => {
  return {
    calender: {
      background:'#fff',
      padding:'20px',
      width:'1100px'
    },
    quick:{
      background:'#fff',
      width:'550px',
      padding:'20px'
    }
  };
});

type WorkType={
  title:string;
  start:Date;
  end:Date;
}
type DateType={
  isWeekend:boolean;
  date:Date;
}


const Home = (props:any) => {
  const { styles } = useStyles();
  const [groups,setGroups ] = useState([])
  const eventPropGetter = useCallback(
    (event, start, end, isSelected) => ({
      ...(event.color && {
        style: {
          backgroundColor: event.color,
        },
      }),
    }),
    []
  )
  const [statisticsData, setStatisticsData] = useState({
    delayQuantity:0,
    earlyQuantity:0,
    lackQuantity:0,
    quantityAbsent:0,
    quantityPresent:0,
    quantityShould:0,
  });
  const [eventsList,setEventsList] = useState<WorkType[]>([])//日历事件列表
  const workDays = useRef<WorkType[]>([])
  const alldays = useRef<DateType[]>([])//当月所有日期
  const [ curYear,setCurYear] = useState(dayjs().year())//当前年份
  const [ curMonth,setCurMonth] = useState(dayjs().month()+1)//当前月份
  const [ curDay,setCurDay] = useState(dayjs().subtract(1, 'day'))//当前日期，默认前一天日期

  const groupFieldNames = {
    label:'name',
    value:'id',
  }

  
  // 修改当前日期
  const changeDate= (date:Dayjs,strdate:string|string[])=>{
    setCurDay(dayjs(date))
  }
  // 修改当前月份 -1 上月 1 下月
  const changeCurMonth = (date:Date|string)=>{
    // 获取当月所有日期
    alldays.current = getAllDatesOfMonth(date)
    console.log(alldays.current,'alldays.current');
    setCurDay(dayjs(date))
  }

  // 上月、下月
  const preNextMonth=(flag:number)=>{
    const today = dayjs(curDay)
    let monthday
    if(flag==1){
      monthday = today.add(1, 'month')
    }else{
      monthday = today.subtract(1, 'month')
    }
    changeCurMonth(monthday.format('YYYY-MM-DD'))
  }

  const getData = ()=>{
    getHome({date:dayjs(curDay).format('YYYY-MM-DD')}).then(res=>{
      if(res.resultCode==0){
        console.log(res.data,'data');
        setStatisticsData(res.data)
      }else{
        message.error(res.message)
      }
    })
  }

  const getGroupData = async () => {
    getAttendanceGroupList({
      pageNo :1,
      pageSize:100,
    }).then(res=>{
      if(res.resultCode==0){
        setGroups(res.data.elements)
      }else{
        message.error(res.message)
      }
    })
  }
  // 选择考勤组
  const getGroup=(id)=>{
    getAttendanceGroup({id:id}).then(res=>{
      if(res.resultCode==0){
        // 日历
        workDays.current=[]
        res.data.details.map(ele=>{
          if(ele.workDate){
            let date = {
              title:ele.scheduleName,
              start:new Date(ele.calenda),
              end:new Date(ele.calenda),
            }
            workDays.current.push(date)
          }
        })
        // 考勤组月份
        setCurDay(dayjs(res.data.details[0].calenda))
        setEventsList(workDays.current)
      }else{
        message.error(res.message)
      }
    })
  }


  useEffect(() => {
    alldays.current = getAllDatesOfMonth(`${dayjs().year()}-${dayjs().month()+1}`)
    getData()
    getGroupData()
    return () => {
    };
  }, []);

  return (
  <>
    <div className="statistics home-box">
    <BtnControl access="/home">
      <li >
        <div className="circle" style={{background:'#5AD8A6'}}><img src={logo} alt="" /></div>
        <div className="text">
          <span>昨日应出勤人数</span>
          <b>{statisticsData.quantityShould}</b>
        </div>
      </li>
      <li >
        <div className="circle" style={{background:'#5B8FF9'}}><img src={logo} alt="" /></div>
        <div className="text">
          <span>昨日已出勤人数</span>
          <b>{statisticsData.quantityPresent}</b>
        </div>
      </li>
      <li >
        <div className="circle" style={{background:'#F6090E'}}><img src={logo2} alt="" /></div>
        <div className="text">
          <span>昨日未出勤人数</span>
          <b>{statisticsData.quantityAbsent}</b>
        </div>
      </li>
      <li >
        <div className="circle" style={{background:'#6DC8EC'}}><img src={logo3} alt="" /></div>
        <div className="text">
          <span>昨日迟到人数</span>
          <b>{statisticsData.delayQuantity}</b>
        </div>
      </li>
      <li >
        <div className="circle" style={{background:'#51D351'}}><img src={logo4} alt="" /></div>
        <div className="text">
          <span>昨日早退人数</span>
          <b>{statisticsData.earlyQuantity}</b>
        </div>
      </li>
      <li >
        <div className="circle" style={{background:'#015478'}}><img src={logo5} alt="" /></div>
        <div className="text">
          <span>昨日缺卡人数</span>
          <b>{statisticsData.lackQuantity}</b>
        </div>
      </li>
      </BtnControl>
    </div>
    <Flex justify='space-between' style={{flex:1,gap:20}}>
      <div className={styles.calender}>
        <Flex justify='space-between'>
          <div className='mb-10'>
            <Button icon={<LeftOutlined />} onClick={()=>preNextMonth(-1)}></Button>
            <DatePicker onChange={changeDate} picker="month" value={curDay}/>
            <Button icon={<RightOutlined />} onClick={()=>preNextMonth(1)}></Button>
          </div>
          <Select
            style={{ width: 150 }}
            onChange={getGroup}
            options={groups}
            fieldNames={groupFieldNames}
            placeholder="请选择考勤组"
          />
        </Flex>
        <Calendar
          localizer={localizer}
          events={eventsList}
          startAccessor="start"
          endAccessor="end"
          defaultDate={new Date()}
          date={new Date(curDay.format('YYYY-MM-DD'))}
          defaultView="month"
          views={['month']}
          style={{ height: 500 }}
          toolbar={false}
          eventPropGetter={eventPropGetter}
        />
      </div>
      <div className={styles.quick}>
        <h3 style={{fontWeight:'bold'}}>快捷菜单</h3>
        <ul className='quick-route'>
          <Link to="/checkin-set/group">
            <li>
              <img src={icon1} alt="" />
              <span>考勤组管理</span>
            </li>
          </Link>
          <Link to="/checkin-set/schedule">
            <li>
              <img src={icon2} alt="" />
              <span>排班管理</span>
            </li>
          </Link>
          <Link to="/org/staff">
            <li>
              <img src={icon3} alt="" />
              <span>员工管理</span>
            </li>
          </Link>
          </ul>
      </div>
    </Flex>
  </>
  )
};

export default Home;