import React, { useState, useEffect } from 'react';
import type { FormProps } from 'antd';
import { Button, Checkbox, Form, Input,Row,Col } from 'antd';
import { Alert, Card, Typography, message } from 'antd';
import {addRole,updateRole,getRole} from '@/services/api/set';
import BtnControl from '@/pages/BtnControl';
import {validateCode} from'@/utils/validate'

type FieldType = {
  code?: string;
  roleName?: string;
};

const UserAdd = (props:any) => {
  const [form] = Form.useForm();
  const [formData, setFormData] = useState({
    id:'',
    roleName:'',
    code:'',
  });

  const getData = ()=>{
    getRole({id:props.rowData.id}).then(res=>{
      if(res.resultCode==0){
        setFormData(res.data)
        form.setFieldsValue(res.data);
      }else{
        message.error(res.message)
      }
    })
  }

  const handleSubmit=()=>{
    form.validateFields().then(async val=>{
      let res
      if(!formData.id||formData.id==''){
        res = await addRole(val)
      }else{
        res = await updateRole({
          id:formData.id,
          roleName:val.roleName,
          code:val.code
        })
      }
      if(res.resultCode==0){
        message.success(res.message)
        props.refresh()
        handleCancel()
      }else{
        message.error(res.message)
      }
    })
  }
  const handleCancel=()=>{
    props.modalClose()
  }

  useEffect(() => {
    if(props.rowData?.id){
      getData()
    }
    return () => {
    };
  }, []);

  return (
  <>
    <Form
      name="form"
      form={form}
      labelCol={{ span: 9}}
      wrapperCol={{ span: 16 }}
      style={{ maxWidth: 600 }}
      autoComplete="off"
      className='modal-form'
    >
      <Row justify='space-between'>
        <Col>
          <Form.Item<FieldType>
          label="编号"
          name="code"
          rules={[{ required: true, validator:validateCode }]}
          >
            <Input />
          </Form.Item>
        </Col>
        <Col>
          <Form.Item<FieldType>
          label="角色名称"
          name="roleName"
          rules={[{ required: true, message: '请输入角色名称' }]}
          >
            <Input />
          </Form.Item>
        </Col>
      </Row>
    </Form>
    <div className="form-btn-box">
      {(!props.rowData?.id||props.rowData?.id=='')&&<BtnControl access="/role/create"><Button type="primary" className='mr-10' onClick={handleSubmit}>确定</Button></BtnControl>}
      {props.rowData&&props.rowData?.id!==''&&<BtnControl access="/role/update"><Button type="primary" className='mr-10' onClick={handleSubmit}>确定</Button></BtnControl>}
      <Button onClick={handleCancel}>取消</Button>
    </div>
  </>
  )
};

export default UserAdd;