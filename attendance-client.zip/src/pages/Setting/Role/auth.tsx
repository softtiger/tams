import type { FormProps } from 'antd';
import { Button, Checkbox, Form, Input,Row,Col,Tree  } from 'antd';
import React, { useState, useEffect } from 'react';
import { Alert, Card, Typography, message } from 'antd';
import type { TreeDataNode, TreeProps } from 'antd';

import {getRoleAuth,setRoleAuth} from '@/services/api/set';
import {generateTree} from '@/utils/createTree';

type TreeType = {
  id: string;
  level: number;
  hasPrivilege: boolean;
  menuName: string;
  parentId: number;
  children?: TreeType[];
};

const UserPsw = (props:any) => {
  const [form] = Form.useForm();
  const [treeData, setTreeData] = useState([] as TreeDataNode[]);
  const [authList, setAuthList] = useState([] as string[]);
  const fieldNames = {
    title: 'menuName', 
    key: 'id', 
    children: 'children'
  }
  const getData = ()=>{
    getRoleAuth({id:props.rowData.id}).then(res=>{
      if(res.resultCode==0){
        setTreeData(generateTree(res.data))
        let arr = [] as string[]
        res.data.map((ele:TreeType)=>{
          if(ele.hasPrivilege)
          arr.push(ele.id) 
        })
        setAuthList([...arr])
      }else{
        message.error(res.message)
      }
    })
  }
  const onSelect: TreeProps['onSelect'] = (selectedKeys, info) => {
    console.log('selected', selectedKeys, info);
  };

  const onCheck: TreeProps['onCheck'] = (checkedKeys, info) => {
    console.log('onCheck', checkedKeys, info);
    if('checked' in checkedKeys){
      setAuthList(checkedKeys.checked as string[])
    }
  };

  // 提交
  const handleSubmit=()=>{
    if(authList.length>0){
      setRoleAuth({
        id:props.rowData.id,
        menuIds:authList.toString()
      }).then(res=>{
        message.success(res.message)
        handleCancel()
      })
    }else{
      message.error('请选择权限')
    }
  }
  const handleCancel=()=>{
    console.log(props);
    props.modalClose()
  }

  useEffect(() => {
    if(props.rowData.id){
      getData()
    }
    return () => {
    };
  }, []);


  return (
  <>
    <Row justify='start'>
      <Col>
        <Tree
          checkable
          className='my-20'
          defaultExpandParent
          checkedKeys={authList}
          onSelect={onSelect}
          onCheck={onCheck}
          treeData={treeData}
          fieldNames={fieldNames}
          checkStrictly
        />
      </Col>
    </Row>
    <div className="form-btn-box">
      <Button type="primary" className='mr-10' onClick={handleSubmit}>确定</Button>
      <Button onClick={handleCancel}>取消</Button>
    </div>
  </>
  )
};

export default UserPsw;