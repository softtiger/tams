import type { FormProps } from 'antd';
import { Button, Checkbox, Form, Input,Row,Col } from 'antd';
import { Alert, Card, Typography, message } from 'antd';
import React, { useState, useEffect } from 'react';

import {upadatePassword} from '@/services/api/set';
import {validatePassword} from '@/utils/validate';

type FieldType = {
  password?: string;
};

const UserPsw = (props:any) => {
  const [form] = Form.useForm();
  const [formData, setFormData] = useState({
    id:'',
    password:'',
  });

  const handleSubmit=()=>{
    form.validateFields().then(val=>{
      upadatePassword({
        id:props.rowData.id,
        password:val.password
      }).then(res=>{
        if(res.resultCode==0){
          message.success(res.message)
          props.refresh()
          handleCancel()
        }else{
          message.error(res.message)
        }
      })
    })
  }

  const handleCancel=()=>{
    console.log(props);
    props.modalClose()
  }

  useEffect(() => {
    if(props.rowData.id){
      setFormData(props.rowData)
    }
    return () => {
      // console.log('组件将卸载');
    };
  }, []);

  return (
  <>
    <Form
      name="form"
      form={form}
      labelCol={{ span: 8}}
      wrapperCol={{ span: 16 }}
      autoComplete="off"
      className='modal-form'
    >
      <Row justify='center'>
        <Col>
          <Form.Item<FieldType>
          label="新密码"
          name="password"
          rules={[{ required: true,validator:validatePassword }]}
          >
            <Input.Password />
          </Form.Item>
        </Col>
      </Row>
    </Form>
    <div className="form-btn-box">
      <Button type="primary" className='mr-10' onClick={handleSubmit}>确定</Button>
      <Button onClick={handleCancel}>取消</Button>
    </div>
  </>
  )
};

export default UserPsw;