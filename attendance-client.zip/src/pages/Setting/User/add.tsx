import type { FormProps } from 'antd';
import { Button, Checkbox, Form, Input,Row,Col } from 'antd';
import { Alert, Card, Typography, message } from 'antd';
import React, { useState, useEffect } from 'react';
import {validatePassword,validateEmail} from '@/utils/validate';
import {addUser,getUser,updateUser} from '@/services/api/set';
import BtnControl from '@/pages/BtnControl';

type FieldType = {
  userName?: string;
  email?: string;
  account?: string;
  password?: string;
};

const UserAdd = (props:any) => {
  const [form] = Form.useForm();
  const [formData, setFormData] = useState({
    id:'',
    userName:'',
    email:'',
    account:'',
    password:'',
  });

  const getData = ()=>{
    getUser({id:props.rowData.id}).then(res=>{
      if(res.resultCode==0){
        setFormData(res.data)
        form.setFieldsValue(res.data);
      }else{
        message.error(res.message)
      }
    })
  }

  // 保存
  const handleSubmit =  ()=>{
    form.validateFields().then(async val=>{
      let res
      if(!formData.id||formData.id==''){
        res = await addUser(val)
      }else{
        res = await updateUser({
          id:formData.id,
          userName:val.userName,
          email:val.email
        })
      }
      if(res.resultCode==0){
        message.success(res.message)
        props.refresh()
        handleCancel()
      }else{
        message.error(res.message)
      }
    })
  }
  const handleCancel=()=>{
    props.modalClose()
  }

  useEffect(() => {
    if(props.rowData?.id){
      getData()
    }
    return () => {
    };
  }, []);


  return (
  <>
    <Form
      name="form"
      form={form}
      labelCol={{ span: 9}}
      wrapperCol={{ span: 16 }}
      style={{ maxWidth: 600 }}
      preserve={false}
      autoComplete="off"
      className='modal-form'
    >
      <Row justify='space-between'>
        <Col span={11}>
          <Form.Item<FieldType>
          label="用户名称"
          name="userName"
          rules={[{ required: true, message: '请输入用户名称' }]}
          >
            <Input />
          </Form.Item>
        </Col>
        <Col span={11}>
          <Form.Item<FieldType>
          label="登陆账号"
          name="account"
          rules={[{ required: true, message: '请输入登陆账号' }]}
          >
            <Input disabled={formData.id!==''}/>
          </Form.Item>
        </Col>
        <Col span={11}>
          <Form.Item<FieldType>
          label="邮箱"
          name="email"
          rules={[{ required: true,validator:validateEmail }]}
          >
            <Input />
          </Form.Item>
        </Col>
        <Col span={11}>
          {!formData.id&&formData.id==''&& <Form.Item<FieldType>
            label="密码"
            name="password"
            rules={[{ required: true,validator:validatePassword }]}
          >
            <Input.Password/>
          </Form.Item>}
        </Col>
      </Row>
    </Form>
    <div className="form-btn-box">
      {(!props.rowData?.id||props.rowData?.id=='')&&<BtnControl access="/account/create"><Button type="primary" className='mr-10' onClick={handleSubmit}>确定</Button></BtnControl>}
      {props.rowData&&props.rowData?.id!==''&&<BtnControl access="/account/update"><Button type="primary" className='mr-10' onClick={handleSubmit}>确定</Button></BtnControl>}
      <Button onClick={handleCancel}>取消</Button>
    </div>
  </>
  )
};

export default UserAdd;