import React, { useState, useEffect,useRef } from 'react';
import { HeartTwoTone, SmileTwoTone } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-components';
import { useIntl } from '@umijs/max';
import { Alert, Card, Typography, message } from 'antd';
import { Button, Col, Form, Input, Row, Select, Space, theme ,Table,Pagination,Switch,Modal } from 'antd';
const { Option } = Select;
import { FormOutlined,SettingOutlined,DeleteOutlined,LockOutlined } from '@ant-design/icons';
import type { PaginationProps } from 'antd';
import type { TableProps } from 'antd';
import {getTenantList} from '@/services/api/set';
import BtnControl from '@/pages/BtnControl';

interface DataType {
  key: string;
  name: string;
  age: number;
  address: string;
  tags: string[];
}

const User: React.FC = () => {
  const intl = useIntl();
  const [form] = Form.useForm();
  const [formData, setformData] = useState({
    name:'',
  });
  const [data, setData] = useState([]);
  const pagination = useRef({
    total:0,
    page:1,
    pageSize: 10,
  })

  const formStyle: React.CSSProperties = {
    maxWidth: 'none',
  };

  const columns: TableProps<DataType>['columns'] = [
    {
      title: '租户名称',
      dataIndex: 'name',
      key: 'name',
      render: (text) => <a>{text}</a>,
    },
    {
      title: '编码',
      dataIndex: 'code',
      key: 'code',
    },
    {
      title: '电话',
      dataIndex: 'phone',
      key: 'phone',
    },
    {
      title: '联系人',
      dataIndex: 'contact',
      key: 'contact',
    },
  ];

  const onFinish = (values: any) => {
    console.log('Received values of form: ', values);
    pagination.current.page = 1
    setformData({...values})
  };

  const onShowSizeChange: PaginationProps['onShowSizeChange'] = (current, pageSize) => {
    console.log(current, pageSize);
  };
  const onPaginatingChange: PaginationProps['onShowSizeChange'] = (current, pageSize) => {
    // console.log(current, pageSize);
    pagination.current.page = current
    getData()
  };

  const getData = async () => {
    getTenantList({
      name:formData.name,
      pageNo :pagination.current.page,
      pageSize:pagination.current.pageSize,
    }).then(res=>{
      if(res.resultCode==0){
        setData(res.data.elements)
        pagination.current.total = res.data.totalCount
      }else{
        message.error(res.message)
      }
    })
  }

  useEffect(() => {
    getData()
    return () => {
    };
  }, [formData]);

  return (
    <PageContainer title={false}>
      <div className="search-box bg-fff p20">
        <Form form={form} name="advanced_search" style={formStyle} layout='inline' onFinish={onFinish}>
          <BtnControl access="/tenant/search">
            <Form.Item name="name">
              <Input placeholder="租户名称模糊搜索" />
            </Form.Item>
          </BtnControl>
        </Form>
      </div>
      <div className="table-box">
        <Table columns={columns} dataSource={data} pagination={false} rowKey="id"/>
        <Pagination
          showSizeChanger
          onShowSizeChange={onShowSizeChange}
          defaultCurrent={1}
          total={pagination.current.total}
          pageSize={10}
          className='mt-10'
          onChange={onPaginatingChange}
        />
      </div>
    </PageContainer>
  );
};

export default User;
