import { HeartTwoTone, SmileTwoTone } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-components';
import { useIntl } from '@umijs/max';
import React, { useState, useEffect,useRef } from 'react';
import { Button, Col, Form, Input, Row, Select, Space, theme ,Table,Pagination,Switch,Modal,Drawer,Tree } from 'antd';
const { Option } = Select;
import { FormOutlined,CheckOutlined,DeleteOutlined,SearchOutlined,UndoOutlined } from '@ant-design/icons';
import type { PaginationProps } from 'antd';
import { createStyles } from 'antd-style';
import type { TableProps } from 'antd';
import { Alert, Card, Typography, message } from 'antd';
import dayjs from 'dayjs';
import {TreeType} from './depart';
import AddRef from './add';
import DetailRef from './detail';
import {getDepartList,getDepartmentList,getStatistics,confirmDepart} from '@/services/api/org';
import {createTree} from '@/utils/createOrgTree';
import BtnControl from '@/pages/BtnControl';

interface DataType {
  id: string;
  leaveTime: string;
  code: string;
  employeeId: number;
  reason: number;
  status: number;
}

const useStyles = createStyles(({ token }) => {
  return {
    wrapper:{
      display:'flex',
    },
    left: {
      width:'250px',
      background:'#fff',
      overflow:'auto',
      padding:'15px',
      marginRight:'15px',
    },
    leftTilte:{
      fontSize:'18px',fontWeight:600,borderBottom:'1px solid #ddd',
      paddingBottom:'10px'
    },
    right:{
      flex:1,
    },
  }
})

const Staff: React.FC = () => {
  const intl = useIntl();
  const [form] = Form.useForm();
  const { styles } = useStyles();

  const [addModal, setAddModal] = useState(false);
  const [editModal, setEditModal] = useState(false);
  const [treeList, setTreeList] = useState<TreeType[]>([]);//部门列表
  const [treeData, setTreeData] = useState<TreeType[]>([]);//部门树形
  const [rowData, setRowData] = useState({});
  const [formData, setformData] = useState({
    content:'',
    status:undefined,
    orgId:'',
  });
  const [data, setData] = useState([]);//选中的部门
  const pagination = useRef({
    total:0,
    page:1,
    pageSize: 10,
  })
  const treeValue =useRef([] as number[])
  const fieldNames = {
    title: 'name', 
    key: 'id', 
    children: 'children'
  }

  const formStyle: React.CSSProperties = {
    maxWidth: 'none',
  };

  const columns: TableProps<DataType>['columns'] = [
    {
      title: '编号',
      dataIndex: 'code',
      key: 'code',
    },
    {
      title: '员工姓名',
      dataIndex: 'fullname',
      key: 'fullname',
    },
    {
      title: '性别',
      dataIndex: 'gender',
      key: 'gender',
      render: (text) => text?<span>男</span>:<span>女</span>,
    },
    {
      title: '手机',
      dataIndex: 'mobile',
      key: 'mobile',
    },
    {
      title: '部门名称',
      dataIndex: 'orgName',
      key: 'orgName',
    },
    {
      title: '职位',
      dataIndex: 'positionName',
      key: 'positionName',
    },
    {
      title: '入职日期',
      dataIndex: 'joinTime',
      key: 'joinTime',
      render: (text) => <span>{dayjs(text).format('YYYY-MM-DD')}</span>,
    },
    {
      title: '离职日期',
      dataIndex: 'leaveTime',
      key: 'leaveTime',
      render: (text) => <span>{dayjs(text).format('YYYY-MM-DD')}</span>,
    },
    {
      title: '离职状态',
      dataIndex: 'status',
      key: 'status',
      render: (text) => text==0?<span className="color-f00">待离职</span>:text==1?<span>已离职</span>:<span>撤回</span>,
    },
    {
      title: '操作',
      key: 'action',
      fixed:'right',
      width:'100px',
      render: (_, record) => (
        <Space size="middle">
          <BtnControl access="/orgDepart/detail">
            {record.status!==0?<Button type="text" icon={<SearchOutlined />} onClick={()=>handleEdit(record)}/>
            :<Button type="text" icon={<CheckOutlined />} onClick={()=>handleEdit(record)}/>}
          </BtnControl>
          <BtnControl access="/orgDepart/confirm">
            {record.status==0?<Button type="text" icon={<UndoOutlined />} onClick={()=>handleWithdraw(record)}/>:''}
          </BtnControl>
        </Space>
      ),
    },
  ];

  // 搜索
  const onInput = () => {
    pagination.current.page = 1
    setformData({...form.getFieldsValue()})
  };
  const onChange = () => {
    pagination.current.page = 1
    setformData({...form.getFieldsValue()})
  };

  const onShowSizeChange: PaginationProps['onShowSizeChange'] = (current, pageSize) => {
    console.log(current, pageSize);
  };
  // 翻页
  const onPaginatingChange: PaginationProps['onShowSizeChange'] = (current, pageSize) => {
    console.log(current, pageSize);
    pagination.current.page = current
    getData()
  };

  const showModal = () => {
    setAddModal(true);
  };
  const handleEdit = (row:DataType) => {
    console.log(row);
    setRowData(row)
    setEditModal(true);
  };

  // 员工列表
  const getData = async () => {
    getDepartList({
      content:formData.content,//姓名或员工编号
      status:formData.status,
      orgId:treeValue.current.toString(),
      pageNo :pagination.current.page,
      pageSize:pagination.current.pageSize,
    }).then(res=>{
      if(res.resultCode==0){
        setData(res.data.elements)
        pagination.current.total = res.data.totalCount
      }
    })
  }

  // 获取所有部门
  const getOrgData = ()=>{
    getDepartmentList({
      pageNo :1,
      pageSize:100,
    }).then(res=>{
      if(res.resultCode==0){
        setTreeList(res.data.elements)
        let tree = createTree(res.data.elements)
        setTreeData(tree as TreeType[])
      }
    })
  }
  // 选择部门
  const onTreeChange = (selectedKeys: React.Key[], info: any) => {
    // console.log(selectedKeys,'newValue');
    treeValue.current = selectedKeys  as number[]
    getData()
  };

  const handleWithdraw = (row:any) => {
    if(!row.id)return
    Modal.confirm({
      title: '撤回该员工离职吗？',
      content: '请谨慎操作！',
      okText: '确定',
      okType: 'danger',
      cancelText: '取消',
      onOk() {
        confirmDepart({
          id:row.id,
          status:false
        }).then(res=>{
          if(res.resultCode==0){
            message.success(res.message)
            getData()
          }
        })
      },
      onCancel() {
        console.log('Cancel');
      },
    });
  };

  const handleCancel = () => {
    setAddModal(false);
    setEditModal(false);
  };

  useEffect(() => {
    getOrgData()
    return () => {
    };
  }, []);

  useEffect(() => {
    getData()
    return () => {
    };
  }, [formData]);

  return (
    <PageContainer title={false}>
      <div className="wrapper">
        {/* 左侧组织树形 */}
        <div className={styles.left}>
          <h2 className={styles.leftTilte}>部门组织</h2>
          { treeData?.length>0&& <Tree
            showLine={true}
            style={{ width: '100%' }}
            treeData={treeData}
            defaultExpandAll={true}
            onSelect={onTreeChange}
            fieldNames={fieldNames}
          />}
        </div>
        {/* 右侧表格 */}
        <div className={styles.right}>
          <div className="search-box bg-fff">
            <Form form={form} name="advanced_search" style={formStyle} layout='inline'>
              <BtnControl access="/orgEmployee/search">
                <Form.Item name="content">
                  <Input placeholder="员工姓名模糊搜索" onPressEnter={onInput}/>
                </Form.Item>
              {/* </BtnControl>
              <BtnControl access="/orgEmployee/search"> */}
                <Form.Item name="status">
                  <Select
                    allowClear
                    style={{width:'150px'}}
                    placeholder="员工状态"
                    onChange={onChange}
                    options={[
                      { value: 0, label: '待离职' },
                      { value: 1, label: '已离职' },
                      { value: 2, label: '撤回' },
                    ]}
                    />
                </Form.Item>
              </BtnControl>
            </Form>
            <div style={{ textAlign: 'right' }}>
              <Space size="small">
                <BtnControl access="/orgEmployee/create">
                  <Button type="primary" onClick={showModal}>
                    新增离职
                  </Button>
                </BtnControl>
              </Space>
            </div>
          </div>
          <div className="table-box">
            <Table columns={columns} dataSource={data} pagination={false} rowKey="id"/>
            <Pagination
              showSizeChanger
              onShowSizeChange={onShowSizeChange}
              defaultCurrent={3}
              total={pagination.current.total}
              className='mt-10'
              onChange={onPaginatingChange}
            />
          </div>
        </div>
      </div>
      <Modal title="新增离职" open={addModal} onCancel={handleCancel} width={700} footer={null} centered destroyOnClose>
        <AddRef modalClose={handleCancel} refresh={getData} />
      </Modal>
      <Drawer title="查看" open={editModal} onClose={handleCancel} width={500} footer={null} destroyOnClose>
        <DetailRef modalClose={handleCancel} refresh={getData} rowData={rowData}/>
      </Drawer>
    </PageContainer>
  );
};

export default Staff;
