import type { FormProps } from 'antd';
import { Button, Checkbox, Form, Input,Row,Col  } from 'antd';
import React, { useState, useEffect,useRef } from 'react';
import { Alert, Card, Typography, message } from 'antd';

import {getPositionList} from '@/services/api/org';

type DataType = {
  id: number;
  name?: string;
  checked?: boolean;
};

const Position = (props:any) => {
  const [form] = Form.useForm();
  const [roleList, setRoleList] = useState([] as DataType[]);
  const [checklist,setChecklist] = useState([] as number[])
  const checked = useRef<DataType>()

  // 获取列表
  const getData = async () => {
    getPositionList({
      pageNo:1,
      pageSize:100,
    }).then(res=>{
      if(res.resultCode==0){
        let arr = res.data.elements.map((ele:DataType)=>{
          ele.checked = false
          return ele
        })
        setRoleList(arr)
      }else{
        message.error(res.message)
      }
    })
  }

  // 选择角色
  const onChange = (e:any,val:DataType) =>{
    console.log(val);
    roleList.map(ele=>ele.checked = false)
    val.checked = e.target.checked
    checked.current = val
    setRoleList([...roleList])
    setChecklist([val?.id])
  }

  // 提交
  const handleSubmit=()=>{
    if(checklist.length>0){
      props.select(checked.current)
      handleCancel()
    }else{
      message.error('请选择职位')
    }
  }
  const handleCancel=()=>{
    console.log(props);
    props.modalClose()
  }

  useEffect(() => {
    getData()
    return () => {
    };
  }, []);


  return (
  <>
    <Form
      name="form"
      form={form}
      wrapperCol={{ span: 24 }}
      initialValues={{ remember: true }}
      autoComplete="off"
      className='modal-form'
    >
      <Row justify='start'>
        <Col>
          <Form.Item
          name="password"
          rules={[{ required: true, message: '请选择角色' }]}
          ><>
              {roleList?.map(ele=>{
                return <Checkbox checked={ele.checked} onChange={(e)=>onChange(e,ele)} key={ele.id} style={{width:'20%'}}>{ele.name}</Checkbox>
              })}
            </>
          </Form.Item>
        </Col>
      </Row>
    </Form>
    <div className="form-btn-box">
      <Button type="primary" className='mr-10' onClick={handleSubmit}>确定</Button>
      <Button onClick={handleCancel}>取消</Button>
    </div>
  </>
  )
};

export default Position;