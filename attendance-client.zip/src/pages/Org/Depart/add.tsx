import type { FormProps } from 'antd';
import { Button, Checkbox, Form, Input,Row,Col,DatePicker,Modal } from 'antd';
import { Alert, Card, Typography, message } from 'antd';
import React, { useState, useEffect,useRef } from 'react';
import type { DatePickerProps } from 'antd';
import dayjs from 'dayjs'

import {addDepart,getPosition,updateDepart} from '@/services/api/org';
import BtnControl from '@/pages/BtnControl';
const { TextArea } = Input;

import SelectUserRef from '@/pages/components/SelectEmployee/index';


type FieldType = {
  employeeId?: string;
  reason?: string;
  leaveTime?: string;
  name?: string;
  id?: number;
  status?: number;
};

const validateInput = (rule: any, value: string): Promise<void> => {  
  return new Promise((resolve, reject) => {  
    if (value.length <= 250 && value.length>=10) {
      resolve();
    } else if(value.length <= 10){
      reject(new Error('不少于10个字符'));
    }
    else {
      reject(new Error('不能超过250个字符'));
    }
  });  
};

const DepartAdd = (props:any) => {
  const [form] = Form.useForm();
  const [userModal,setUserModal] = useState(false);
  const [formData, setFormData] = useState({
    id:'',
    leaveTime:'',
    employeeId:'',
    name:'',
    status:0,
    reason:'',
  });
  const employeeId = useRef('')

  const getData = ()=>{
    getPosition({id:props.rowData.id}).then(res=>{
      if(res.resultCode==0){
        setFormData(res.data)
        form.setFieldsValue(res.data);
      }else{
        message.error(res.message)
      }
    })
  }

  // 打开选择窗口
  const openUserModal = ()=>{
    setUserModal(true)
  }

  // 修改时间
  const onDateChange : DatePickerProps['onChange'] = (date, dateString)=>{
    // console.log(date.format('YYYY-MM-DD'));
    setFormData({
      ...form.getFieldsValue(),
      leaveTime:date.format('YYYY-MM-DD HH:mm:ss')
    });
  }
  // 选择员工
  const selectUser = (val:{
    fullname:string;
    id:string;
  })=>{
    setFormData({
      ...formData,
      name:val.fullname
    })
    employeeId.current = val.id
  }

  const onChange = ()=>{
    setFormData({
      ...form.getFieldsValue(),
    })
  }

  // 保存
  const handleSubmit =  ()=>{
    form.validateFields().then(async val=>{
      console.log(formData);
      let res
      if(!formData.id||formData.id==''){
        res = await addDepart({
          ...val,
          employeeId:employeeId.current,
          status:0
        })
      }else{
        res = await updateDepart({
          id:val.id,
          name:val.name,
        })
      }
      if(res.resultCode==0){
        message.success(res.message)
        props.refresh()
        handleCancel()
      }else{
        message.error(res.message)
      }
    })
  }
  const handleCancel=()=>{
    props.modalClose()
  }
  const close=()=>{
    setUserModal(false)
  }

  useEffect(() => {
    if(props.rowData?.id){
      getData()
    }
    return () => {
    };
  }, []);

  useEffect(() => {
    form.setFieldsValue(formData)
    return () => {
    };
  }, [formData]);

  return (
  <>
    <Form
      name="form"
      form={form}
      labelCol={{
        style: { width: 100 }
      }}
      wrapperCol={{ span: 20 }}
      style={{ maxWidth: 600 }}
      initialValues={{}}
      preserve={false}
      autoComplete="off"
      className='modal-form'
    >
      <Row justify='space-between'>
        <Col span={11}>
          <Form.Item<FieldType>
          label="员工"
          name="name"
          rules={[{ required: true, message: '请选择员工' }]}
          >
            <Input placeholder='请选择员工' onClick={openUserModal}/>
          </Form.Item>
        </Col>
        <Col span={11}>
          <Form.Item<FieldType>
            label="离职时间"
            name="leaveTime"
            rules={[{ required: true, message: '请选择离职时间' }]}
            getValueFromEvent={(...[, dateString]) => dateString}
            getValueProps={(value) => ({value: value ? dayjs(value,'YYYY-MM-DD'): undefined})}
            >
              <DatePicker onChange={onDateChange} style={{ width: '100%' }} 
              format="YYYY-MM-DD" />
            </Form.Item>
        </Col>
        <Col span={24}>
          <Form.Item<FieldType>
          label="离职原因"
          name="reason"
          rules={[{ required: true, validator:validateInput }]}
          >
            <TextArea rows={4} maxLength={250} placeholder='请输入离职原因' onChange={(onChange)}/>
          </Form.Item>
        </Col>
      </Row>
    </Form>
    <div className="form-btn-box">
      {(!props.rowData?.id||props.rowData?.id=='')&&<BtnControl access="/orgDepart/create"><Button type="primary" className='mr-10' onClick={handleSubmit}>确定</Button></BtnControl>}
      {props.rowData&&props.rowData?.id!==''&&<BtnControl access="/orgDepart/update"><Button type="primary" className='mr-10' onClick={handleSubmit}>确定</Button></BtnControl>}
      <Button onClick={handleCancel}>取消</Button>
    </div>
    <Modal title="选择员工" open={userModal} onCancel={close} width={500} footer={null} centered destroyOnClose>
      <SelectUserRef modalClose={close} select={selectUser}/>
    </Modal>
  </>
  )
};

export default DepartAdd;