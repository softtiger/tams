import type { FormProps } from 'antd';
import { Button, Checkbox, Form, Input,Row,Col,Select,DatePicker,Modal } from 'antd';
import { Alert, Card, Typography, message } from 'antd';
import React, { useState, useEffect,useRef } from 'react';
import type { DatePickerProps } from 'antd';
import {addEmployee,getDepart,updateEmployee,confirmDepart} from '@/services/api/org';
import BtnControl from '@/pages/BtnControl';
import Department from './depart';
import Position from './posi';

import dayjs from 'dayjs'
const { TextArea } = Input;

type FieldType = {
  code?: string;
  orgName?: string;
  fullname?: string;
  positionName?: string;
  id?: number;
  orgId?: number;
  positionId?: number;
  status?: number;
  classification?: number;
  gender?: boolean;
  name:'',
  reason:'',
  mobile:'',
  joinTime:'',
  empStatus:'',
};


const Detail= (props:any) => {
  const [form] = Form.useForm();
  const [departModal, setDepartModal] = useState(false);
  const [posiModal, setPosiModal] = useState(false);
  const [formData, setFormData] = useState({
    id:'',
    name:'',
    status:'',//离职状态
    code:'',
    orgId:'',
    orgName:'',
    positionName:'',
    positionId:'',
    reason:'',
    empStatus:'',//员工正式、试用
  });
  const orgId = useRef('')
  const positionId = useRef('')


  // 获取员工详情
  const getData = ()=>{
    getDepart({id:props.rowData.id}).then(res=>{
      if(res.resultCode==0){
        setFormData(res.data)
        form.setFieldsValue(res.data);
        orgId.current = res.data.orgId
        positionId.current = res.data.positionId
      }else{
        message.error(res.message)
      }
    })
  }


  // 修改时间
  const onDateChange : DatePickerProps['onChange'] = (date, dateString)=>{
    console.log(date.format('YYYY-MM-DD'));
    setFormData({
      ...form.getFieldsValue(),
      joinTime:date.format('YYYY-MM-DD HH:mm:ss')
    });
  }

  // 打开选择部门
  const openDepart = () => {
    setDepartModal(true)
  };
  // 打开选择职位
  const openPosition = () => {
    setPosiModal(true)
  };

  // 选择部门
  const selectDepart = (val:{
    id:string;
    name:string;
  }) => {
    console.log(val,'选择的部门');
    setFormData({
      ...formData,
      orgId:val.id,
      orgName:val.name
    })
    orgId.current = val.id
    form.setFieldsValue(formData);
  };

  // 选择职位
  const selectPosition = (val:{
    id:string;
    name:string;
  }) => {
    console.log(val,'选择的职位');
    setFormData({
      ...formData,
      positionId:val.id,
      positionName:val.name
    })
    positionId.current = val.id
  };


  // 确认离职
  const handleSubmit =  ()=>{
    confirmDepart({
      id:props.rowData.id,
      status:true
    }).then(res=>{
      if(res.resultCode==0){
        message.success(res.message)
        props.refresh()
        handleCancel()
      }
    })
  }
  const handleCancel=()=>{
    props.modalClose()
  }

  const modalCancel = ()=>{
    setDepartModal(false);
    setPosiModal(false)
  }

  useEffect(() => {
    if(props.rowData?.id){
      getData()
    }
    return () => {
    };
  }, []);
  useEffect(() => {
    // console.log(formData);
    form.setFieldsValue(formData)
    return () => {
    };
  }, [formData]);


  return (
  <>
    <Form
      name="form"
      form={form}
      labelCol={{ span: 7}}
      wrapperCol={{ span: 14 }}
      style={{ maxWidth: 600 }}
      initialValues={{}}
      preserve={false}
      autoComplete="off"
      className='modal-form'
    >
      <Row justify='space-between'>
        <Col span={24}>
          <Form.Item<FieldType>
          label="员工编号"
          name="code"
          className='readonly'
          >
            <Input/>
          </Form.Item>
        </Col>
        <Col span={24}>
          <Form.Item<FieldType>
          label="姓名"
          name="fullname"
          className='readonly'
          >
            <Input/>
          </Form.Item>
        </Col>
        <Col span={24}>
          <Form.Item<FieldType>
          label="性别"
          className='readonly'
          name="gender"
          rules={[{ required: true, message: '请选择性别' }]}
          >
            <Select
              allowClear
              options={[
                { value: true, label: '男' },
                { value: false, label: '女' },
              ]}
            />
          </Form.Item>
        </Col>
        <Col span={24}>
          <Form.Item<FieldType>
          label="手机"
          className='readonly'
          name="mobile"
          rules={[{ required: false, message: '请输入手机号' }]}
          >
            <Input/>
          </Form.Item>
        </Col>
        <Col span={24}>
          <Form.Item<FieldType>
          label="入职日期"
          className='readonly'
          name="joinTime"
          rules={[{ required: true, message: '请选择入职日期' }]}
          getValueFromEvent={(...[, dateString]) => dateString}
          getValueProps={(value) => ({value: value ? dayjs(value,'YYYY-MM-DD'): undefined})}
          >
            <DatePicker onChange={onDateChange} style={{ width: '100%' }} 
            format="YYYY-MM-DD" />
          </Form.Item>
        </Col>
        <Col span={24}>
          <Form.Item<FieldType>
          label="部门"
          className='readonly'
          name="orgName"
          rules={[{ required: true, message: '请输入姓名' }]}
          >
            <Input onClick={openDepart}/>
          </Form.Item>
        </Col>
        <Col span={24}>
          <Form.Item<FieldType>
          label="职位"
          className='readonly'
          name="positionName"
          rules={[{ required: true, message: '请选择职位' }]}
          >
            <Input onClick={openPosition}/>
          </Form.Item>
        </Col>
        <Col span={24}>
          <Form.Item<FieldType>
          label="员工类型"
          className='readonly'
          name="classification"
          rules={[{ required: true, message: '请选择员工类型' }]}
          >
            <Select
              allowClear
              options={[
                { value: 1, label: '全职' },
                { value: 2, label: '兼职' },
                { value: 3, label: '实习' },
              ]}
            />
          </Form.Item>
        </Col>
        <Col span={24}>
          <Form.Item<FieldType>
          label="员工状态"
          className='readonly'
          name="empStatus"
          rules={[{ required: true, message: '请选择员工状态' }]}
          >
            <Select
              allowClear
              options={[
                { value: 1, label: '正式' },
                { value: 2, label: '试用' },
                { value: 3, label: '已离职' },
              ]}
            />
          </Form.Item>
        </Col>
        <Col span={24}>
          <Form.Item<FieldType>
          label="离职原因"
          name="reason"
          rules={[{ required: true, message: '请输入离职原因' }]}
          >
            <TextArea rows={4} maxLength={250} placeholder='请输入离职原因'/>
          </Form.Item>
        </Col>
      </Row>
    </Form>
    <div className="form-btn-box">
      <BtnControl access="/orgDepart/confirm"><Button type="primary" className='mr-10' onClick={handleSubmit}>确认离职</Button></BtnControl>
      <Button onClick={handleCancel}>取消</Button>
    </div>
    <Modal title="选择部门" open={departModal} onCancel={modalCancel} width={700} footer={null} centered destroyOnClose>
      <Department modalClose={modalCancel} select={selectDepart} />
    </Modal>
    <Modal title="选择职位" open={posiModal} onCancel={modalCancel} width={700} footer={null} centered destroyOnClose>
      <Position modalClose={modalCancel} select={selectPosition}/>
    </Modal>
  </>
  )
};

export default Detail;