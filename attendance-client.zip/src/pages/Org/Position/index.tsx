import { PageContainer } from '@ant-design/pro-components';
import { useIntl } from '@umijs/max';
import React, { useState, useEffect,useRef } from 'react';
import { Button, Col, Form, Input, Row, Select, Space, theme ,Table,Pagination,Switch,Modal } from 'antd';
const { Option } = Select;
import { FormOutlined,SettingOutlined,DeleteOutlined,LockOutlined } from '@ant-design/icons';
import type { PaginationProps } from 'antd';
import type { TableProps } from 'antd';
import { Alert, Card, Typography, message } from 'antd';
import AddRef from './add';
import {getPositionList,upadatePositionStatus} from '@/services/api/org';
import BtnControl from '@/pages/BtnControl';

interface DataType {
  id: string;
  name: string;
  status: boolean;
  address: string;
}

const User: React.FC = () => {
  const intl = useIntl();
  const [form] = Form.useForm();
  const [addModal, setAddModal] = useState(false);
  const [editModal, setEditModal] = useState(false);
  const [rowData, setRowData] = useState({});
  const [formData, setformData] = useState({
    name:'',
  });
  const [data, setData] = useState([]);
  const pagination = useRef({
    total:0,
    page:1,
    pageSize: 10,
  })

  const formStyle: React.CSSProperties = {
    maxWidth: 'none',
  };

  const columns: TableProps<DataType>['columns'] = [
    {
      title: '编号',
      dataIndex: 'code',
      key: 'code',
    },
    {
      title: '职位名称',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      render: (_, record) => (
        <BtnControl access="/orgPosition/toggle"><Switch checkedChildren="on" unCheckedChildren="off" checked={record.status} onChange={()=>handleStatus(record)}/></BtnControl>
      ),
    },
    {
      title: '操作',
      key: 'action',
      fixed:'right',
      width:'200px',
      render: (_, record) => (
        <Space size="middle">
          <BtnControl access="/orgPosition/detail"><Button type="text" icon={<FormOutlined />} onClick={()=>handleEdit(record)}/></BtnControl>
        </Space>
      ),
    },
  ];

  const onFinish = (values: any) => {
    console.log('Received values of form: ', values);
    pagination.current.page = 1
    setformData({...values})
  };

  const onShowSizeChange: PaginationProps['onShowSizeChange'] = (current, pageSize) => {
    console.log(current, pageSize);
  };
  const onPaginatingChange: PaginationProps['onShowSizeChange'] = (current, pageSize) => {
    console.log(current, pageSize);
    pagination.current.page = current
    getData()
  };

  const showModal = () => {
    setAddModal(true);
  };
  const handleEdit = (row:DataType) => {
    console.log(row);
    setRowData(row)
    setEditModal(true);
  };

  const getData = async () => {
    console.log('用户列表');
    getPositionList({
      name:formData.name,//姓名或员工编号
      pageNo :pagination.current.page,
      pageSize:pagination.current.pageSize,
    }).then(res=>{
      if(res.resultCode==0){
        setData(res.data.elements)
        pagination.current.total = res.data.totalCount
      }else{
        message.error(res.message)
      }
    })
  }

  const handleStatus = (row:DataType) => {
    upadatePositionStatus({
      id:row.id,
      enabled:!row.status
    }).then(res=>{
      if(res.resultCode==0){
        message.success(res.message)
        getData()
      }
    })
  }

  const handleOk = () => {
    setAddModal(false);
  };

  const handleCancel = () => {
    setAddModal(false);
    setEditModal(false);
  };

  useEffect(() => {
    getData()
    return () => {
    };
  }, [formData]);

  return (
    <PageContainer title={false}>
      <div className="search-box bg-fff p20">
        <Form form={form} name="advanced_search" style={formStyle} layout='inline' onFinish={onFinish}>
          <BtnControl access="/orgPosition/search">
            <Form.Item name="name">
              <Input placeholder="职位名称模糊搜索"/>
            </Form.Item>
          </BtnControl>
        </Form>
        <div style={{ textAlign: 'right' }}>
          <BtnControl access="/orgPosition/create">
            <Space size="small">
              <Button type="primary" onClick={showModal}>
                新增职位
              </Button>
            </Space>
          </BtnControl>
        </div>
      </div>
      <div className="table-box">
        <Table columns={columns} dataSource={data} pagination={false} rowKey="id"/>
        <Pagination
          showSizeChanger
          onShowSizeChange={onShowSizeChange}
          defaultCurrent={pagination.current.page}
          total={pagination.current.total}
          className='mt-10'
          onChange={onPaginatingChange}
        />
      </div>
      <Modal title="新增" open={addModal} onOk={handleOk} onCancel={handleCancel} width={700} footer={null} centered destroyOnClose>
        <AddRef modalClose={handleCancel} refresh={getData}/>
      </Modal>
      <Modal title="修改" open={editModal} onOk={handleOk} onCancel={handleCancel} width={700} footer={null} centered destroyOnClose>
        <AddRef modalClose={handleCancel} refresh={getData} rowData={rowData}/>
      </Modal>
    </PageContainer>
  );
};

export default User;
