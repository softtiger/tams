import type { FormProps } from 'antd';
import { Button, Checkbox, Form, Input,Row,Col,TreeSelect,Select  } from 'antd';
import { Alert, Card, Typography, message } from 'antd';
import React, { useState, useEffect } from 'react';

import {getDepartmentList,getDepartment,addDepartment,updateDepartment} from '@/services/api/org';
import {createTree} from '@/utils/createOrgTree';
import BtnControl from '@/pages/BtnControl';

type FieldType = {
  name?: string;
  type?: string;
  parentOrg?: string;
  code?: string;
};

const validateInput = (rule: any, value: string): Promise<void> => {  
  return new Promise((resolve, reject) => {  
    let pattern = /^[0-9]+$/
    if (!value) {  
      return reject(new Error('请输入编号'));  
    }  
    if (value.length >= 3 && value.length <= 6 && pattern.test(value)) {
      resolve();
    } else {
      reject(new Error('请输入3-6个字符的数字编号'));
    } 
  });  
}; 
const validateInput2 = (rule: any, value: string): Promise<void> => {  
  return new Promise((resolve, reject) => {  
    if (!value) {  
      return reject(new Error('请输入姓名'));  
    }  
    if (value.length >=2 && value.length <= 20) {
      resolve();
    } else {
      reject(new Error('请输入2-20个字符的职位名称'));
    } 
  });  
};


const UserAdd = (props:any) => {
  const [form] = Form.useForm();
  const fieldNames = {
    label: 'name', 
    value: 'id', 
    children: 'children'
  }
  const [formData, setFormData] = useState({
    id:'',
    name:'',
    type:1,//1 企业 2子公司 3部门
    parentOrg:'',
    code:'',
  });
  const [treeValue, setTreeValue] = useState([] as any[]);
  const [treeData, setTreeData] = useState([] as any[]);

  const validateParent = (rule: any, value: string): Promise<void> => {  
    let type = form.getFieldValue('type')
    return new Promise((resolve, reject) => { 
      if (!value && type==1) {
        return resolve();
      } 
      if (type!==1 && (!value||value=='')) {
        reject(new Error('请选择上级部门'));
      } else {
        resolve();
      }
    });  
  };

  // 获取部门信息
  const getData = ()=>{
    getDepartment({id:props.rowData.id}).then(res=>{
      if(res.resultCode==0){
        setFormData(res.data)
        form.setFieldsValue(res.data);
      }else{
        message.error(res.message)
      }
    })
  }
  // 获取所有部门
  const getOrgData = ()=>{
    getDepartmentList({
      pageNo :1,
      pageSize:100,
    }).then(res=>{
      if(res.resultCode==0){
        setTreeValue(res.data.elements)
        let tree = createTree(res.data.elements)
        console.log(tree,'tree');
        setTreeData(tree)
      }
    })
  }
  // 选择上级
  const onTreeChange = (newValue: string) => {
    console.log(newValue,'newValue');
    let cur = treeValue.find(ele=>ele.id==newValue)
    setFormData({
      ...form.getFieldsValue(),
      parentOrg:newValue,
      type: cur?cur.type+1:null
    });
  };


  // 保存
  const handleSubmit =  ()=>{
    form.validateFields().then(async val=>{
      let res
      if(!props.rowData?.id||props.rowData?.id==''){
        res = await addDepartment(val)
      }else{
        res = await updateDepartment({
          id:props.rowData?.id,
          name:val.name,
          parentOrg:val.parentOrg,
          code:val.code,
          type:val.type,
        })
      }
      if(res.resultCode==0){
        message.success(res.message)
        props.refresh()
        handleCancel()
      }else{
        message.error(res.message)
      }
    })
  }
  const handleCancel=()=>{
    props.modalClose()
  }

  useEffect(() => {
    getOrgData()
    if(props.rowData?.id){
      getData()
    }
    return () => {
    };
  }, []);


  return (
  <>
    <Form
      name="form"
      form={form}
      labelCol={{ span: 9}}
      wrapperCol={{ span: 16 }}
      style={{ maxWidth: 600 }}
      initialValues={{}}
      preserve={false}
      autoComplete="off"
      className='modal-form'
    >
      <Row justify='space-between'>
        <Col span={11}>
          <Form.Item<FieldType>
          label="编号"
          name="code"
          rules={[{ required: true, validator:validateInput }]}
          >
            <Input/>
          </Form.Item>
        </Col>
        <Col span={11}>
          <Form.Item<FieldType>
          label="部门名称"
          name="name"
          rules={[{ required: true, validator:validateInput2 }]}
          >
            <Input/>
          </Form.Item>
        </Col>
        <Col span={11}>
          <Form.Item<FieldType>
          label="部门类型"
          name="type"
          initialValue={1}
          rules={[{ required: true, message: '请输入部门类型' }]}
          >
            <Select
              allowClear
              options={[
                { value: 1, label: '一级企业' },
                { value: 2, label: '二级企业' },
                { value: 3, label: '部门' },
              ]}
            />
          </Form.Item>
        </Col>
        <Col span={11}>
          <Form.Item<FieldType>
          label="上级部门"
          name="parentOrg"
          style={{width:'100%'}}
          rules={[{ required: false,validator:validateParent }]}
          >
            <TreeSelect
              showSearch
              treeLine={true}
              allowClear
              style={{ width: '100%' }}
              value={formData.parentOrg}
              dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
              treeData={treeData}
              placeholder="请选择上级部门"
              treeDefaultExpandAll
              onChange={onTreeChange}
              fieldNames={fieldNames}
            />
          </Form.Item>
        </Col>
      </Row>
    </Form>
    <div className="form-btn-box">
      {(!props.rowData?.id||props.rowData?.id=='')&&<BtnControl access="/orgDepart/create"><Button type="primary" className='mr-10' onClick={handleSubmit}>确定</Button></BtnControl>}
      {props.rowData&&props.rowData?.id!==''&&<BtnControl access="/orgDepart/update"><Button type="primary" className='mr-10' onClick={handleSubmit}>确定</Button></BtnControl>}
      <Button onClick={handleCancel}>取消</Button>
    </div>
  </>
  )
};

export default UserAdd;