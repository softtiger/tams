import React from 'react';
import { Event } from 'react-big-calendar';
import { formatLunarDate } from 'lunar-calendar';

const LunarEvent = ({ event }) => {
  const startDate = new Date(event.start);
  const endDate = new Date(event.end);
  const lunarStartDate = formatLunarDate(startDate);
  const lunarEndDate = formatLunarDate(endDate);

  return (
    <div>
      <strong>{event.title}</strong>
      <br />
      {lunarStartDate} - {lunarEndDate}
    </div>
  );
};

export default LunarEvent;
