import type { FormProps } from 'antd';
import { Button, Checkbox, Form, Input,Row,Col,Tree  } from 'antd';
import React, { useState, useEffect,useRef } from 'react';
import { Alert, Card, Typography, message } from 'antd';
import type { TreeDataNode, TreeProps } from 'antd';
import { createStyles } from 'antd-style';

import {getDepartmentList,getEmployeeList} from '@/services/api/org';
import {createTree} from '@/utils/createOrgTree';

const useStyles = createStyles(({ token }) => {
  return {
    container: {
      border:'1px solid #ddd',
    },
    search:{
      padding:'5px',
      borderBottom:'1px solid #ddd'
    },
    list:{
      borderLeft:'1px solid #ddd',
      minHeight:'500px',
      overflow:'auto',
    },
    li:{
      padding:'10px 15px',
      borderBottom:'1px solid #ddd',
      display:'flex',
      justifyContent:'space-between'
    }
  };
});

type TreeType = {
  id: number;
  level: number;
  hasPrivilege: boolean;
  menuName: string;
  parentId: number;
  children?: TreeType[];
};

const Employee = (props:any) => {
  const [form] = Form.useForm();
  const { styles } = useStyles();
  // const [treeValue, setTreeValue] = useState([] as number[]);//选中的部门
  // const [treeList, setTreeList] = useState();//部门列表
  const [treeData, setTreeData] = useState([] as any[]);//部门树形
  const [userList, setUserList] = useState([] as any[]);//员工列表
  const [userValue,setUserValue] = useState({});//选中的员工
  // const [name, setName] = useState('');

  const fieldNames = {
    title: 'name', 
    key: 'id', 
    children: 'children'
  }
  const pagination = useRef({
    total:0,
    page:1,
    pageSize: 100,
  })
  const treeValue = useRef()
  const name = useRef()

  // 获取部门列表，并生成树形
  const getData = ()=>{
    getDepartmentList({
      pageNo :1,
      pageSize:100,
    }).then(res=>{
      if(res.resultCode==0){
        let tree = createTree(res.data.elements)
        setTreeData(tree)
      }
    })
  }

  // 获取员工列表
  const getUserData = async () => {
    getEmployeeList({
      content:name.current,//姓名或员工编号
      orgId:treeValue.current,
      pageNo :pagination.current.page,
      pageSize:pagination.current.pageSize,
    }).then(res=>{
      if(res.resultCode==0){
        let arr = res.data.elements.map(ele=>{
          ele.check = true
          ele.employeeName = ele.fullname
          return ele
        })
        setUserList(arr)
        pagination.current.total = res.data.totalCount
      }
    })
  }
  // 选择部门筛选员工
  const onSelect: TreeProps['onSelect'] = (selectedKeys, info) => {
    // console.log('selected', selectedKeys, info);
    // setTreeValue(info.node?.id)
    treeValue.current = info.node?.id
    getUserData()
  };

  // 搜索人员姓名
  const changeNameSearch = (e) => {
    // setName(e.target.value)
    name.current = e.target.value
    getUserData()
  }


  // 选中员工,单选
  const onUserCheck = (val)=>{
    let arr = userList.map(ele=>{
      ele.check = false
      if(ele.id==val.id)
      ele.check = true
      return ele
    })
    setUserList(arr)
    setUserValue(val)
  }

  // 提交
  const handleSubmit=()=>{
    if(userList.length>0){
      props.select(userList)
      handleCancel()
    }else{
      message.error('请选择员工')
    }
  }
  const handleCancel=()=>{
    // console.log(props);
    props.modalClose()
  }

  useEffect(() => {
    getData()
    getUserData()
    return () => {
      // console.log('组件将卸载');
    };
  }, []);


  return (
  <>
    <div className={styles.container}>
      <Row justify='start'>
        <Col className={styles.search} span={24}>
          <Input placeholder='搜索人员' value={name.current} onChange={changeNameSearch}/>
        </Col>
      </Row>
      <Row justify='start'>
        <Col span={10}>
          {treeData.length>0 && <Tree
          className='my-20'
          showLine
          defaultExpandAll
          onSelect={onSelect}
          treeData={treeData}
          fieldNames={fieldNames}
          />}
        </Col>
        <Col span={14} className={styles.list}>
          {userList.length>0&& userList.map(ele=>(
            <div className={styles.li} key={ele.id}>{ele.fullname}
              <Checkbox checked={ele.check} ></Checkbox>
            </div>
          ))}
        </Col>
      </Row>
    </div>
    <div className="form-btn-box mt-10">
      <Button type="primary" className='mr-10' onClick={handleSubmit}>确定</Button>
      <Button onClick={handleCancel}>取消</Button>
    </div>
  </>
  )
};

export default Employee;