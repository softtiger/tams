import React, { useState, useEffect } from 'react';
import {hasBtnPermission} from '@/utils/btnAuth';


const BtnControl = (props:any) => {
  const {children,userInfo,access} = props
  const visiableAuth = (node)=>{
    if(!access||access==''){
      return null
    }else{
      const result = hasBtnPermission(access)
      return result?node:null
    }
  }

  return (
  <>
  {visiableAuth(children)}
  </>
  )
};

export default BtnControl;