export function getAllDatesOfMonth(day:Date|string) {
    var now = new Date(day);
    var firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    var lastDayOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    var allDates = [];
  
    for (var i = firstDayOfMonth; i <= lastDayOfMonth; i.setDate(i.getDate() + 1)) {
      var date = new Date(i);
      var dayOfWeek = date.getDay();
      var isWeekend = (dayOfWeek === 6) || (dayOfWeek === 0); // 周六和周日为休息日
      allDates.push({
        date: date,
        isWeekend: isWeekend
      });
    }
  
    return allDates;
  }



export function getAllDatesInRange(startDate: Date, endDate: Date): Date[] {  
  let dates = [];  
  let currentDate = new Date(startDate);  
  let endDateTime = endDate.getTime(); // 将结束日期转换为时间戳以便比较  
  // 确保循环在结束日期之前结束（包括结束日期）  
  while (currentDate.getTime() <= endDateTime - 86400000) {  // 日历传入的时间总是多一天，这里减去
    dates.push(new Date(currentDate)); // 添加当前日期的副本到列表中  
    currentDate.setDate(currentDate.getDate() +1); // 将当前日期增加一天  
  }  
  return dates;  
} 
  