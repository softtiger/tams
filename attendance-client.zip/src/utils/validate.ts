// 定义邮箱验证的正则表达式类型  
const emailRegex: RegExp = /^([a-zA-Z0-9_.-])+@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-])+/;  
  
// 邮箱验证函数  
export const validateEmail = (rule: any, value: string): Promise<void> => {  
  return new Promise((resolve, reject) => {  
    if (!value) {  
      return reject(new Error('请输入邮箱'));  
    }  
    if (emailRegex.test(value)) {  
      resolve();  
    } else {  
      reject(new Error('请输入正确的邮箱'));  
    }  
  });  
}; 
  
// 密码验证函数  
export const validatePassword = (rule: any, value: string): Promise<void> => {  
  return new Promise((resolve, reject) => {  
    if (!value) {  
      return reject(new Error('请输入密码'));  
    }  
    if (value.length >= 6 && value.length <= 12) {  
      resolve();  
    } else {  
      reject(new Error('请输入6~12位的密码'));  
    }  
  });  
}; 
  
// 编号验证函数  
export const validateCode = (rule: any, value: string): Promise<void> => {  
  return new Promise((resolve, reject) => {  
    if (!value) {  
      return reject(new Error('请输入编号'));  
    }  
    if (value.length >= 6 && value.length <= 20) {  
      resolve();  
    } else {  
      reject(new Error('请输入6~20位的编号'));  
    }  
  });  
}; 
