export type PermissionCode = "1001" | "1002" | "1003" | String
export type nodeType = {
    menuId: number;
    menuName: string; 
    menuType: string;
    menuUrl: string; 
    authority: string
}

export const hasBtnPermission = (btnUrl: PermissionCode) => {
    let authlist = JSON.parse(localStorage.getItem('authorized-navgation')||'')
    let allbtns = authlist.filter((ele:nodeType)=>ele.menuType=='btn')
    // 按钮所需单个权限code
    if (!Array.isArray(btnUrl)) {
        return !!allbtns.find((ele:nodeType)=>ele.authority==btnUrl) 
    }
}
