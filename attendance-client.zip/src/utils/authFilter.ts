
export async function filterTokenPermission(menu?: API.Router_Type[]): Promise<API.Router_Type[] | undefined> {
    let authlist = JSON.parse(localStorage.getItem('authorized-navgation')||"")
    let accessedRoutes
  
    // 获取当前系统的菜单
    if(menu && menu.length){
      accessedRoutes = filterAsyncRoutes(menu,authlist)// 路由，权限表
    }
    return accessedRoutes
  
    // 过滤
    function filterAsyncRoutes(routes:API.Router_Type[],authlist:any[]) {
      const arr: API.Router_Type[] = []
      if(authlist.length==0)return arr
      routes.forEach((route:API.Router_Type) => {
        const tmp = { ...route }
        // console.log(tmp,'一级路由');
        if (hasPermission(tmp,authlist)) {
          // 路由只有一个子集时默认加入
          if (tmp.routes && tmp.routes.length>1 ) {
            tmp.routes = filterAsyncRoutes(tmp.routes,authlist)
          }
          arr.push(tmp)
        }
      })
      return arr
    }
  
    // 判断权限
    function hasPermission(route:API.Router_Type,authlist:any[]) {
      let auths = authlist
      if ((route.path && auths && auths.length>0)) {
        return auths.some(item => {
          // 有redirect的一级路由，放过
          if (route.name==item.menuName||route.redirect||route.path == '/'||route.path=='/welcome'||route.path=='*')
          return true
          if(item.routes&&item.routes>0)
          hasPermission(route,item.routes)
          return false
        })
      } else {
        return false
      }
    }
  }