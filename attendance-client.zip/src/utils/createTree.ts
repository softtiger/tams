import type { TreeDataNode, TreeProps } from 'antd';
  
  interface TreeNode {
    id: number;
    level: number;
    hasPrivilege: boolean;
    menuName: string;
    parentId: number;
    children?: TreeNode[];
    key?: string;
  }
  
  interface DataNode extends TreeDataNode{
    id:number;
    children?: DataNode[];
  }

  
  export function generateTree<T extends TreeNode>(arr: T[]): DataNode[] {
    const tree: DataNode[] = [];
    for (let i = 0; i < arr.length; i++) {
      const item = arr[i];
      const treeNode: DataNode = {  
        ...item, // 复制所有属性  
        key: item.key ?? item.id.toString(), // 使用 key 或 id 作为 key  
        title: item.menuName, // 使用 menuName 作为 title  
        children: undefined, // 初始时 children 是未定义的  
      };  
      if (item.level === 1) {
        tree.push(item as DataNode);
      } else {
        const parent = findParent(tree, item.parentId) as DataNode;
        if (parent !== null) {
          if (!parent.children) {
            parent.children = [];
          }
          parent.children.push(treeNode);
        }
      }
    }
    return tree;
  }
  
  function findParent<T extends DataNode>(arr: T[], parentId: number|string): DataNode | null {
    for (let i = 0; i < arr.length; i++) {
      const item = arr[i];
      if (item.id === parentId) {
        return item;
      } else if (item.children) {
        const parent = findParent(item.children, parentId);
        if (parent !== null) {
          return parent;
        }
      }
    }
    return null;
  }
  