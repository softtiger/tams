import dayjs, { Dayjs } from 'dayjs'
import duration from 'dayjs/plugin/duration';
dayjs.extend(duration);

export const calMinutes = (timeStart,timeEnd) => {
    const startTime = dayjs().format('YYYY-MM-DD') +' '+ timeStart +':00'
    const endTime = dayjs().format('YYYY-MM-DD')+' '+timeEnd +':00'

    const start = dayjs(startTime);
    const end = dayjs(endTime)
    
    const duration = end.diff(start);
    const minutes = dayjs.duration(duration).asMinutes()
    return minutes
}

// 分钟转小时
export const calHours = (minutes) => {
    let hour = minutes / 60
    return hour
}